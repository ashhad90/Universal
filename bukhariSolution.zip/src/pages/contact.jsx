function contact() {
    return (

        <div className="wrapper">
            <div className="preloader">
                <div className="loading"><span /><span /><span /><span /></div>
            </div>{/* /.preloader */}
            {/* =========================
          Header
      =========================== */}
            <header className="header header-transparent">
                <nav className="navbar navbar-expand-lg sticky-navbar">
                    <div className="container">
                        <a className="navbar-brand" href="index">
                            <img src="assets/images/logo/logo-light.png" className="logo-light" alt="logo" />
                            <img src="assets/images/logo/logo-dark.png" className="logo-dark" alt="logo" />
                        </a>
                        <button className="navbar-toggler" type="button">
                            <span className="menu-lines"><span /></span>
                        </button>
                        <div className="collapse navbar-collapse" id="mainNavigation">
                            <ul className="navbar-nav ml-auto">
                                <li className="nav__item">
                                    <a href="/" className="dropdown-toggle nav__item-link">Home</a>
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="about-us" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Company</a>
                                    <ul className="dropdown-menu">
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">About Us</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">CEO Message</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">Our Mission</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">Our Values</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">Our Team</a>
                                        </li>{/* /.nav-item */}
                                    </ul>{/* /.dropdown-menu */}
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Services</a>
                                    <ul className="dropdown-menu">
                                        <li className="nav__item">
                                            <a href="salesforce" className="nav__item-link">CRM/Salesforce</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="analytics" className="nav__item-link">BI &amp; Analytics</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="digital-marketing" className="nav__item-link">Digital Marketing</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="development" className="nav__item-link">Software Development</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="database" className="nav__item-link">Database Development</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="quality-assurance" className="nav__item-link">Quality Assurance</a>
                                        </li>{/* /.nav-item */}
                                    </ul>{/* /.dropdown-menu */}
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Events</a>
                                    <ul className="dropdown-menu">
                                        <li className="nav__item">
                                            <a href="#" className="nav__item-link">News</a>
                                        </li>{/* /.nav-item */}
                                    </ul>{/* /.dropdown-menu */}
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="career" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Career</a>
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Blog</a>
                                </li>{/* /.nav-item */}
                                <li className="nav__item">
                                    <a href="contact" className="nav__item-link active">Contacts</a>
                                </li>{/* /.nav-item */}
                            </ul>{/* /.navbar-nav */}
                            <button className="close-mobile-menu d-block d-lg-none"><i className="fas fa-times" /></button>
                        </div>{/* /.navbar-collapse */}
                    </div>{/* /.container */}
                </nav>{/* /.navabr */}
            </header>{/* /.Header */}
            {/* ========================
         page title 
      =========================== */}
            <section className="page-title page-title-layout1 bg-overlay bg-overlay-gradient bg-parallax text-center">
                <div className="bg-img"><img src="assets/images/page-titles/contact.jpg" alt="background" /></div>
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-12 col-xl-6 offset-xl-3">
                            <h1 className="pagetitle__heading">Contact Us</h1>
                            <p className="pagetitle__desc mb-0">          </p>
                        </div>{/* /.col-xl-6 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.page-title */}
            {/* ==========================
          contact box
      =========================== */}
            <section className="contact-layout1 pt-0 mt--100">
                <div className="container">
                    <div className="row">
                        <div className="col-12">
                            <div className="contact-panel d-flex flex-wrap">
                                <div className="contact-panel__info">
                                    <div className="bg-img"><img src="assets/images/backgrounds/3.jpg" alt="banner" /></div>
                                    <div className="contact-block">
                                        <h5 className="contact-block__title">Ready To Make a Real Change?</h5>
                                        <ul className="contact-block__list list-unstyled">
                                            <li>Let’s Build this Thing Together! You can connect with us any time</li>
                                        </ul>
                                    </div>
                                    <div className="contact-block">
                                        <h5 className="contact-block__title">Quick Contact</h5>
                                        <ul className="contact-block__list list-unstyled">
                                            <li><a href="mailto: " />Email: consult@bssuniversal.com</li>
                                            <li><a href="mailto: " />Support: support@bssuniversal.com</li>
                                        </ul>
                                    </div>{/* /.contact-panel__info__block */}
                                    {/*
                  <div class="contact-block">
                    <h5 class="contact-block__title">Opening Hours</h5>
                    <ul class="contact-block__list list-unstyled">
                      <li>Monday - Friday</li>
                      <li>09:00 AM - 06:00 PM</li>
                    </ul>
                  </div>
  */}
                                    {/*
                  <p class="color-white mb-20">If you have any questions or need help, feel free to contact with our team.
                  </p>
                  <a href="tel:01061245741" class="phone-number">
                    <i class="icon-phone"></i> <span>+92-42-35210600</span>
                  </a>
  */}
                                </div>
                                <form className="contact-panel__form" method="post" action="https://www.bssuniversal.com/assets/php/contact.php" id="contactForm">
                                    <div className="row">
                                        <div className="col-sm-12">
                                            <h4 className="contact-panel__title">Get In Touch</h4>
                                            <p className="contact-panel__desc mb-20">Our highly experienced and certified engineers and IT staff are ready to
                                                help you to keep your IT business safe &amp; ensure high availability.</p>
                                        </div>
                                        <div className="col-sm-6 col-md-6 col-lg-6">
                                            <div className="form-group">
                                                <input type="text" className="form-control" placeholder="Name" id="contact-name" name="contact-name" required />
                                            </div>
                                        </div>{/* /.col-lg-6 */}
                                        <div className="col-sm-6 col-md-6 col-lg-6">
                                            <div className="form-group">
                                                <input type="email" className="form-control" placeholder="Email" id="contact-email" name="contact-email" required />
                                            </div>
                                        </div>{/* /.col-lg-6 */}
                                        <div className="col-sm-6 col-md-6 col-lg-6">
                                            <div className="form-group">
                                                <input type="text" className="form-control" placeholder="Phone" id="contact-Phone" name="contact-phone" required />
                                            </div>
                                        </div>{/* /.col-lg-6 */}
                                        <div className="col-sm-6 col-md-6 col-lg-6">
                                            <div className="form-group">
                                                <input type="text" className="form-control" placeholder="Website (optional)" id="contact-website" name="contact-website" />
                                            </div>
                                        </div>{/* /.col-lg-6 */}
                                        <div className="col-12">
                                            <div className="form-group">
                                                <textarea className="form-control" placeholder="Describe your inquirey!" id="contact-message" name="contact-message" defaultValue={""} />
                                            </div>
                                            <button type="submit" className="btn btn__primary btn__icon btn__xhight mt-10">
                                                <span>Submit Request</span> <i className="icon-arrow-right" />
                                            </button>
                                            <div className="contact-result" />
                                        </div>{/* /.col-lg-12 */}
                                    </div>{/* /.row */}
                                </form>
                            </div>
                        </div>{/* /.col-lg-6 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.contact box */}
            {/* ==========================
         Office Contact Info
      ============================ */}
            <section className="contact-info pt-0 pb-70">
                <div className="container">
                    <div className="row">
                        {/* Contact panel #1 */}
                        <div className="col-sm-12 col-md-4 col-lg-4">
                            <div className="contact-info-box">
                                <h4 className="contact__info-box-title">Dubai Office</h4>
                                <ul className="contact__info-list list-unstyled">
                                    {/*                <li>Email: <a href="mailto:consult@bssuniversal.com">consult@bssuniversal.com</a></li>*/}
                                    <li>Address: Unit #101, Building A2, Dubai Silicon Oasis, UAE.</li>
                                    {/*                <li>Phone: <a href="tel:092-42-35210600">+92-42-35210600</a></li>*/}
                                    {/*                <li>Hours: Mon-Fri: 8am – 7pm</li>*/}
                                </ul>{/* /.contact__info-list */}
                            </div>{/* /.contact-info-box */}
                        </div>{/* /.col-lg-4 */}
                        {/* Contact panel #2 */}
                        <div className="col-sm-12 col-md-4 col-lg-4">
                            <div className="contact-info-box">
                                <h4 className="contact__info-box-title">United States Office</h4>
                                <ul className="contact__info-list list-unstyled">
                                    {/*                <li>Email: <a href="mailto:consult@bssuniversal.com">consult@bssuniversal.com</a></li>*/}
                                    <li>Address: 1016 N Highland Ave Arlington Heights IL 60004 United States</li>
                                    {/*                <li>Phone: <a href="tel:092-42-35210600">+92-42-35210600</a></li>*/}
                                    {/*                <li>Hours: Mon-Fri: 8am – 7pm</li>*/}
                                </ul>{/* /.contact__info-list */}
                            </div>{/* /.contact-info-box */}
                        </div>{/* /.col-lg-4 */}
                        {/* Contact panel #3 */}
                        <div className="col-sm-12 col-md-4 col-lg-4">
                            <div className="contact-info-box">
                                <h4 className="contact__info-box-title">Pakistan Office</h4>
                                <ul className="contact__info-list list-unstyled">
                                    {/*                <li>Email: <a href="mailto:consult@bssuniversal.com">consult@bssuniversal.com</a></li>*/}
                                    <li>Address: 25 B Valancia Town, Lahore, Pakistan</li>
                                    {/*                <li>Phone: <a href="tel:092-42-35210600">+92-42-35210600</a></li>*/}
                                    {/*                <li>Hours: Mon-Fri: 8am – 7pm</li>*/}
                                </ul>{/* /.contact__info-list */}
                            </div>{/* /.contact-info-box */}
                        </div>{/* /.col-lg-4 */}
                        {/* Contact panel #4 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.Office Contact Info */}
            {/* ========================
       Counters
      =========================== */}
            <section className="counters pt-60">
                <div className="container">
                    <div className="row">
                        {/* counter item #1 */}
                        <div className="col-sm-6 col-md-3 col-lg-3">
                            <div className="counter-item">
                                <h4 className="counter">1,311</h4>
                                <p className="counter__desc">Projects And Software Developed Till 2021</p>
                            </div>{/* /.counter-item */}
                        </div>{/* /.col-lg-3 */}
                        {/* counter item #2 */}
                        <div className="col-sm-6 col-md-3 col-lg-3">
                            <div className="counter-item">
                                <h4 className="counter">115</h4>
                                <p className="counter__desc">Qualified Employees And Developers With Us</p>
                            </div>{/* /.counter-item */}
                        </div>{/* /.col-lg-3 */}
                        {/* counter item #3 */}
                        <div className="col-sm-6 col-md-3 col-lg-3">
                            <div className="counter-item">
                                <h4 className="counter">5,200</h4>
                                <p className="counter__desc">Satisfied Users We Have Served Globally</p>
                            </div>{/* /.counter-item */}
                        </div>{/* /.col-lg-3 */}
                        {/* counter item #4 */}
                        <div className="col-sm-6 col-md-3 col-lg-3">
                            <div className="counter-item">
                                <h4 className="counter">15</h4>
                                <p className="counter__desc">Years Of Experience In The IT &amp; Software Industry</p>
                            </div>{/* /.counter-item */}
                        </div>{/* /.col-lg-3 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.counters */}
            {/* ========================
          Footer
        ========================== */}
            <footer className="footer bg-secondary">
                <div className="container">
                    <div className="footer-top pt-50 pb-30">
                        <div className="row">
                            <div className="col-sm-4 col-md-2 col-lg-4">
                                <img src="assets/images/logo/logo-light-small.png" alt="logo" className="mb-30" />
                            </div>{/* /.col-lg-2 */}
                            <div className="col-sm-8 col-md-4 col-lg-3">
                                <h6 className="footer-top__title">Sign up for latest IT resources,
                                    news and insights from BSS!</h6>
                            </div>{/* /.col-lg-3 */}
                            <div className="col-sm-12 col-md-6 col-lg-5">
                                <form className="footer-form d-flex mb-0">
                                    <input type="email" className="form-control mr-20" placeholder="Your Email Address" />
                                    <button type="submit" className="btn btn__primary btn__primary-style2">
                                        <span>Subscribe</span>
                                        <i className="icon-arrow-right" />
                                    </button>
                                </form>
                            </div>{/* /.col-lg-6 */}
                        </div>{/* /.row */}
                    </div>{/* /.footer-top */}
                    <div className="footer-primary">
                        <div className="row">
                            <div className="col-sm-12 col-md-12 col-lg-4 footer-widget footer-widget-about">
                                <div className="footer-widget__content">
                                    <div className="contact-info">
                                        <h6 className="footer-widget__title">Quick Contact</h6>
                                        <ul className="contact-list list-unstyled">
                                            <li className="color-gray">If you have any questions or need help, feel free to contact with our team.
                                            </li>
                                            <li className="mt-20 mb-20">
                                                <a href="mailto:consult@bssuniversal.com" className="phone-number">
                                                    <span>consult@bssuniversal.com</span>
                                                </a>
                                            </li>
                                            <li className="color-body"><a href="contact">Dubai | United States | Pakistan</a></li>
                                        </ul>
                                    </div>{/* /.contact-info */}
                                    <ul className="social-icons list-unstyled mb-0">
                                        <li><a href="https://www.facebook.com/bssuniversal" target="_blank"><i className="fab fa-facebook-f" /></a></li>
                                        <li><a href="https://www.linkedin.com/company/bssuniversal/" target="_blank"><i className="fab fa-linkedin" /></a></li>
                                        <li><a href="https://twitter.com/bssuniversal" target="_blank"><i className="fab fa-twitter" /></a></li>
                                        <li><a href="https://www.instagram.com/bss.global12/?hl=en" target="_blank"><i className="fab fa-instagram" /></a></li>
                                    </ul>{/* /.social-icons */}
                                </div>{/* /.footer-widget__content */}
                            </div>{/* /.col-xl-2 */}
                            <div className="col-sm-6 col-md-6 col-lg-3 offset-lg-1 footer-widget footer-widget-nav">
                                <h6 className="footer-widget__title">Company</h6>
                                <div className="footer-widget__content">
                                    <nav>
                                        <ul className="list-unstyled">
                                            <li><a href="about-us">About Us</a></li>
                                            <li><a href="about-us">Our Team</a></li>
                                            <li><a href="#">Event &amp; News</a></li>
                                            <li><a href="#">Blog &amp; Article</a></li>
                                            <li><a href="career">Career</a></li>
                                            <li><a href="contact">Contacts</a></li>
                                        </ul>
                                    </nav>
                                </div>{/* /.footer-widget__content */}
                            </div>{/* /.col-lg-2 */}
                            <div className="col-sm-6 col-md-6 col-lg-4 footer-widget footer-widget-nav">
                                <h6 className="footer-widget__title">Solutions</h6>
                                <div className="footer-widget__content">
                                    <nav>
                                        <ul className="list-unstyled">
                                            <li><a href="salesforce">CRM/Salesforce</a></li>
                                            <li><a href="analytics">BI &amp; Analytics</a></li>
                                            <li><a href="digital-marketing">Digital Marketing</a></li>
                                            <li><a href="development">Software Development</a></li>
                                            <li><a href="database">Database Development</a></li>
                                            <li><a href="quality-assurance">Quality Assurance</a></li>
                                        </ul>
                                    </nav>
                                </div>{/* /.footer-widget__content */}
                            </div>{/* /.col-lg-2 */}
                            {/*
              <div class="col-sm-6 col-md-6 col-lg-3 footer-widget footer-widget-nav">
                <h6 class="footer-widget__title">Memberships</h6>
                <div class="footer-widget__content">
                  <nav>
                    <ul class="list-unstyled">
                      <li><a href="http://www.bssuniversal.com/images/PSEB%202019-2020.jpg">Pakistan Software Export Board</a></li>
                      <li><a href="http://www.bssuniversal.com/images/P@sha-Membership-Certificate-2021-22.jpg">Pakistan Software Houses Association</a></li>
                      <li><a href="http://www.bssuniversal.com/images/LCCI%20CERTIFICATION.jpg">Lahore Chamber of Commerce & Industry</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
  */}
                        </div>{/* /.row */}
                    </div>{/* /.footer-primary */}
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-12 text-center pb-40">
                            <span className="fz-14">© 2021 BSS Universal, All Rights Reserved.</span>
                        </div>{/* /.col-lg-12 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </footer>{/* /.Footer */}
            <button id="scrollTopBtn"><i className="fas fa-long-arrow-alt-up" /></button>
        </div>
    );
}

export default contact;