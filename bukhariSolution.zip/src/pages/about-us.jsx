function about() {
    return (

        <div className="wrapper">
            <div className="preloader">
                <div className="loading"><span /><span /><span /><span /></div>
            </div>{/* /.preloader */}
            {/* =========================
                  Header
              =========================== */}
            <header id="top_header_line" className="header header-transparent">
                <nav className="navbar navbar-expand-lg sticky-navbar">
                    <div className="container">
                        <a className="navbar-brand" href="/">
                            <img src="assets/images/logo/logo-light.png" className="logo-light" alt="logo" />
                            <img src="assets/images/logo/logo-dark.png" className="logo-dark" alt="logo" />
                        </a>
                        <button className="navbar-toggler" type="button">
                            <span className="menu-lines"><span /></span>
                        </button>
                        <div className="collapse navbar-collapse" id="mainNavigation">
                            <ul className="navbar-nav ml-auto">
                                <li className="nav__item">
                                    <a href="/" className="dropdown-toggle nav__item-link">Home</a>
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link active">Company</a>
                                    <ul className="dropdown-menu">
                                        <li className="nav__item">
                                            <a href="#" className="nav__item-link">About Us</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="#" className="nav__item-link">CEO Message</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="#" className="nav__item-link">Our Mission</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="#" className="nav__item-link">Our Values</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="#" className="nav__item-link">Our Team</a>
                                        </li>{/* /.nav-item */}
                                    </ul>{/* /.dropdown-menu */}
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Services</a>
                                    <ul className="dropdown-menu">
                                        <li className="nav__item">
                                            <a href="salesforce" className="nav__item-link">CRM/Salesforce</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="analytics" className="nav__item-link">BI &amp; Analytics</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="digital-marketing" className="nav__item-link">Digital Marketing</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="development" className="nav__item-link">Software Development</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="database" className="nav__item-link">Database Development</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="quality-assurance" className="nav__item-link">Quality Assurance</a>
                                        </li>{/* /.nav-item */}
                                    </ul>{/* /.dropdown-menu */}
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Events</a>
                                    <ul className="dropdown-menu">
                                        <li className="nav__item">
                                            <a href="#" className="nav__item-link">News</a>
                                        </li>{/* /.nav-item */}
                                    </ul>{/* /.dropdown-menu */}
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="career" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Career</a>
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Blog</a>
                                </li>{/* /.nav-item */}
                                <li className="nav__item">
                                    <a href="contact" className="nav__item-link">Contacts</a>
                                </li>{/* /.nav-item */}
                            </ul>{/* /.navbar-nav */}
                            <button className="close-mobile-menu d-block d-lg-none"><i className="fas fa-times" /></button>
                        </div>{/* /.navbar-collapse */}
                    </div>{/* /.container */}
                </nav>{/* /.navabr */}
            </header>{/* /.Header */}
            {/* ========================
                 page title 
              =========================== */}
            <section className="page-title page-title-layout1 bg-overlay bg-overlay-gradient bg-parallax text-center">
                <div className="bg-img"><img src="assets/images/page-titles/1.jpg" alt="background" /></div>
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-12 col-xl-6 offset-xl-3">
                            <h1 className="pagetitle__heading">About Us</h1>
                            <p className="pagetitle__desc mb-0">We believe in thinking beyond the scope of our company to contribute positively towards making this world a better place.
                            </p>
                        </div>{/* /.col-xl-6 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.page-title */}
            {/* ========================
                Secondary Nav
              =========================== */}
            <section className="secondary-nav secondary-nav-internal-navigation sticky-top py-0">
                <div className="container">
                    <div className="row">
                        <div className="col-12">
                            <nav className="nav nav-tabs justify-content-center">
                                <a href="#" data-scroll="top_header_line" className="nav__link active">About Us</a>
                                <a href="#" data-scroll="message" className="nav__link">CEO Message</a>
                                <a href="#" data-scroll="mission" className="nav__link">Our Mission</a>
                                <a href="#" data-scroll="values" className="nav__link">Our Values</a>
                                <a href="#" data-scroll="team" className="nav__link">Our Team</a>
                            </nav>
                        </div>{/* /.col-12 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.Secondary Nav */}
            {/* ========================
                CEO Message
              =========================== */}
            <section id="message" className="about-layout1 pb-130">
                <div className="container">
                    <div className="row align-items-end">
                        <div className="col-sm-12 col-md-12 col-lg-6 col-xl-5">
                            <div className="about__img">
                                <img src="assets/images/about/2.jpg" alt="about" />
                            </div>{/* /.about-img */}
                        </div>{/* /.col-xl-5 */}
                        <div className="col-sm-12 col-md-12 col-lg-6 col-xl-6 offset-xl-1">
                            <div className="heading-layout2">
                                <h2 className="heading__subtitle">CEO Message</h2>
                                <h3 className="heading__title mb-30">Look Forward to Achieve an Exponential Growth Curve</h3>
                            </div>{/* /heading */}
                            <div className="about__Text">
                                <p className="mb-30">BSS is in the process of moving its main office to Dubai, UAE. Although, each of our entities will continue to operate independently, we also want to establish Dubai as our main hub to have a better global reach.</p>
                                <p className="mb-30">Over the years, we have distinguished ourselves as a company with an insightful vision and a strategic path. The customers of today look for trustworthy partners who are able to come up with unique solutions to cater to their needs in an increasingly volatile environment.</p>
                                <p className="mb-30">BSS believes to invest in its human capital which enabled it to develop a team of highly skillful and smart individuals, working on the latest cutting-edge technology. We have been able to build our footprint as a reliable and exceptional service provider. BSS is now expanding its wings to new markets and looks forward to achieving an exponential growth curve. </p>
                            </div>
                            <img src="assets/images/about/singnture.png" alt="singnture" className="mt-30" />
                        </div>{/* /.col-xl-7 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.CEO Message */}
            {/* ========================
                Our Mission
              =========================== */}
            <section id="mission" className="about-layout2 pt-130 pb-90">
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-12 col-xl-6 offset-xl-1">
                            <div className="sticky-top">
                                <h2 className="heading__subtitle">Our Mission!</h2>
                                <h3 className="heading__title">Our core focus is to provide Quality services.</h3>
                                <p>BSS operates with an agile delivery framework to provide robust, reliable and scalable solutions for our clients surpassing their business expectations. We offer services in Salesforce, BI, AWS and Data Science. In a focus to minimize customer’s time, cost and hassle we have added an array of ancillary services like business process modeling and analysis; website and graphic design, comprehensive testing of existing software solutions, and an uninterrupted support service for our developed solutions. </p>
                                <p>We worked hard on developing a passionate team with innovative mindsets and extensive training to help our customers in resolving their multifaceted problems. </p>
                            </div>
                        </div>{/* /.col-xl-7 */}
                        <div className="col-sm-12 col-md-12 col-lg-12 col-xl-5">
                            <div className="about__img mb-40">
                                <img src="assets/images/about/1.jpg" alt="about" />
                            </div>{/* /.about-img */}
                        </div>{/* /.col-xl-5 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.Our Mission */}
            {/* ======================
              Our Values Timeline
              ========================= */}
            <section id="values" className="history-timeline pt-130 pb-130">
                <div className="bg-img"><img src="assets/images/backgrounds/2.jpg" alt="background" /></div>
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-6">
                            <h2 className="heading__subtitle color-primary">Our Values!!</h2>
                            <h3 className="heading__title color-white">Revolutionary Steps for Revolutionary Business</h3>
                        </div>{/* /.col-lg-6 */}
                        <div className="col-sm-12 col-md-6 col-lg-6">
                            <div>
                                {/* timeline Item #1 */}
                                <div className="timeline-item d-flex">
                                    <h4 className="timeline__year">Integrity</h4>
                                    <p className="timeline__desc">Our credo is to act ethically, assume accountability and provide you with open and honest feedback.
                                    </p>
                                </div>{/* /.timeline-item */}
                                {/* timeline Item #2 */}
                                <div className="timeline-item d-flex">
                                    <h4 className="timeline__year">Stewardship</h4>
                                    <p className="timeline__desc">We subscribe to the notion that taking ownership and responsibility takes precedence over everything else.</p>
                                </div>{/* /.timeline-item */}
                                {/* timeline Item #3 */}
                                <div className="timeline-item d-flex">
                                    <h4 className="timeline__year">Collaboration</h4>
                                    <p className="timeline__desc">Together with our clients, we work to achieve common goals through transparency and knowledge sharing.</p>
                                </div>{/* /.timeline-item */}
                                {/* timeline Item #4 */}
                                <div className="timeline-item d-flex">
                                    <h4 className="timeline__year">Client Selection</h4>
                                    <p className="timeline__desc">We take pride in working with organization that are deemed “World Class”- that respect exceptional quality service and offer greater rewards.</p>
                                </div>{/* /.timeline-item */}
                                {/* timeline Item #5 */}
                                <div className="timeline-item d-flex">
                                    <h4 className="timeline__year">Best People</h4>
                                    <p className="timeline__desc">By hiring and retaining the best people for the job, we provide you the finest quality service ensuring your success.
                                    </p>
                                </div>{/* /.timeline-item */}
                                {/* timeline Item #6 */}
                                <div className="timeline-item d-flex">
                                    <h4 className="timeline__year">Value<br />Creation</h4>
                                    <p className="timeline__desc">We strive to consistently provide you with efficient and a cost-effective service – creating long-term win-win relationships.
                                    </p>
                                </div>{/* /.timeline-item */}
                                {/* timeline Item #7 */}
                                <div className="timeline-item d-flex">
                                    <h4 className="timeline__year">Philanthropy</h4>
                                    <p className="timeline__desc">We believe in thinking beyond the scope of our company to contribute positively towards making this world a better place.
                                    </p>
                                </div>{/* /.timeline-item */}
                                {/* timeline Item #8 */}
                                <div className="timeline-item d-flex">
                                    <h4 className="timeline__year">Business Process learning &amp; Continuous education</h4>
                                    <p className="timeline__desc">We incentivize and ensure our team learns client’s business processes and becomes an extension of their business team.
                                    </p>
                                </div>{/* /.timeline-item */}
                            </div>
                        </div>{/* /.col-lg-6 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.Our Values Timeline */}
            {/* ========================
               Our Team
              =========================== */}
            <section id="team" className="gallery pt-130 pb-90">
                <div className="container max-width-1300">
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-12 col-xl-6">
                            <div className="gallery-images-wrapper">
                                <a className="popup-gallery-item" href="assets/images/gallery/1.jpg">
                                    <img src="assets/images/gallery/1.jpg" alt="gallery img" />
                                </a>
                                <a className="popup-gallery-item" href="assets/images/gallery/2.jpg">
                                    <img src="assets/images/gallery/2.jpg" alt="gallery img" />
                                </a>
                                <a className="popup-gallery-item" href="assets/images/gallery/3.jpg">
                                    <img src="assets/images/gallery/3.jpg" alt="gallery img" />
                                </a>
                                <a className="popup-gallery-item" href="assets/images/gallery/4.jpg">
                                    <img src="assets/images/gallery/4.jpg" alt="gallery img" />
                                </a>
                            </div>{/* /.gallery-images-wrapper */}
                        </div>{/* /.col-xl-5 */}
                        <div className="col-sm-12 col-md-12 col-lg-12 col-xl-5 offset-xl-1">
                            <div className="sticky-top">
                                <h2 className="heading__subtitle">Our Team! Take the World at new Level</h2>
                                <h3 className="heading__title">Our success today is the reflection of its strong family of competent and meticulous employees.</h3>
                                <p>The selection of the team is the core strength of BSS based on a very extensive and vigorous screening to make sure the employee matches our philosophy, ethical standards as well as the knowledge base required to achieve the job description.</p>
                                <p>We encourage and patronize employee skill development through training and providing career growth opportunities. We promote transparency, respect and diversity in our team. BSS maintains a congenial and motivational environment to help each team member to perform its best.</p>
                            </div>
                        </div>{/* /.col-xl-7 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.Our Team */}
            {/* ========================
               Counters
              =========================== */}
            <section className="counters pt-60">
                <div className="container">
                    <div className="row">
                        {/* counter item #1 */}
                        <div className="col-sm-6 col-md-3 col-lg-3">
                            <div className="counter-item">
                                <h4 className="counter">1,311</h4>
                                <p className="counter__desc">Projects And Software Developed Till 2021</p>
                            </div>{/* /.counter-item */}
                        </div>{/* /.col-lg-3 */}
                        {/* counter item #2 */}
                        <div className="col-sm-6 col-md-3 col-lg-3">
                            <div className="counter-item">
                                <h4 className="counter">115</h4>
                                <p className="counter__desc">Qualified Employees And Developers With Us</p>
                            </div>{/* /.counter-item */}
                        </div>{/* /.col-lg-3 */}
                        {/* counter item #3 */}
                        <div className="col-sm-6 col-md-3 col-lg-3">
                            <div className="counter-item">
                                <h4 className="counter">5,200</h4>
                                <p className="counter__desc">Satisfied Users We Have Served Globally</p>
                            </div>{/* /.counter-item */}
                        </div>{/* /.col-lg-3 */}
                        {/* counter item #4 */}
                        <div className="col-sm-6 col-md-3 col-lg-3">
                            <div className="counter-item">
                                <h4 className="counter">15</h4>
                                <p className="counter__desc">Years Of Experience In The IT &amp; Software Industry</p>
                            </div>{/* /.counter-item */}
                        </div>{/* /.col-lg-3 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.counters */}
            {/* ========================
                  Footer
                ========================== */}
            <footer className="footer bg-secondary">
                <div className="container">
                    <div className="footer-top pt-50 pb-30">
                        <div className="row">
                            <div className="col-sm-4 col-md-2 col-lg-4">
                                <img src="assets/images/logo/logo-light-small.png" alt="logo" className="mb-30" />
                            </div>{/* /.col-lg-2 */}
                            <div className="col-sm-8 col-md-4 col-lg-3">
                                <h6 className="footer-top__title">Sign up for latest IT resources,
                                    news and insights from BSS!</h6>
                            </div>{/* /.col-lg-3 */}
                            <div className="col-sm-12 col-md-6 col-lg-5">
                                <form className="footer-form d-flex mb-0">
                                    <input type="email" className="form-control mr-20" placeholder="Your Email Address" />
                                    <button type="submit" className="btn btn__primary btn__primary-style2">
                                        <span>Subscribe</span>
                                        <i className="icon-arrow-right" />
                                    </button>
                                </form>
                            </div>{/* /.col-lg-6 */}
                        </div>{/* /.row */}
                    </div>{/* /.footer-top */}
                    <div className="footer-primary">
                        <div className="row">
                            <div className="col-sm-12 col-md-12 col-lg-4 footer-widget footer-widget-about">
                                <div className="footer-widget__content">
                                    <div className="contact-info">
                                        <h6 className="footer-widget__title">Quick Contact</h6>
                                        <ul className="contact-list list-unstyled">
                                            <li className="color-gray">If you have any questions or need help, feel free to contact with our team.
                                            </li>
                                            <li className="mt-20 mb-20">
                                                <a href="mailto:consult@bssuniversal.com" className="phone-number">
                                                    <span>consult@bssuniversal.com</span>
                                                </a>
                                            </li>
                                            <li className="color-body"><a href="contact">Dubai | United States | Pakistan</a></li>
                                        </ul>
                                    </div>{/* /.contact-info */}
                                    <ul className="social-icons list-unstyled mb-0">
                                        <li><a href="https://www.facebook.com/bssuniversal" target="_blank"><i className="fab fa-facebook-f" /></a></li>
                                        <li><a href="https://www.linkedin.com/company/bssuniversal/" target="_blank"><i className="fab fa-linkedin" /></a></li>
                                        <li><a href="https://twitter.com/bssuniversal" target="_blank"><i className="fab fa-twitter" /></a></li>
                                        <li><a href="https://www.instagram.com/bss.global12/?hl=en" target="_blank"><i className="fab fa-instagram" /></a></li>
                                    </ul>{/* /.social-icons */}
                                </div>{/* /.footer-widget__content */}
                            </div>{/* /.col-xl-2 */}
                            <div className="col-sm-6 col-md-6 col-lg-3 offset-lg-1 footer-widget footer-widget-nav">
                                <h6 className="footer-widget__title">Company</h6>
                                <div className="footer-widget__content">
                                    <nav>
                                        <ul className="list-unstyled">
                                            <li><a href="about-us">About Us</a></li>
                                            <li><a href="about-us">Our Team</a></li>
                                            <li><a href="#">Event &amp; News</a></li>
                                            <li><a href="#">Blog &amp; Article</a></li>
                                            <li><a href="career">Career</a></li>
                                            <li><a href="contact">Contacts</a></li>
                                        </ul>
                                    </nav>
                                </div>{/* /.footer-widget__content */}
                            </div>{/* /.col-lg-2 */}
                            <div className="col-sm-6 col-md-6 col-lg-4 footer-widget footer-widget-nav">
                                <h6 className="footer-widget__title">Solutions</h6>
                                <div className="footer-widget__content">
                                    <nav>
                                        <ul className="list-unstyled">
                                            <li><a href="salesforce">CRM/Salesforce</a></li>
                                            <li><a href="analytics">BI &amp; Analytics</a></li>
                                            <li><a href="digital-marketing">Digital Marketing</a></li>
                                            <li><a href="development">Software Development</a></li>
                                            <li><a href="database">Database Development</a></li>
                                            <li><a href="quality-assurance">Quality Assurance</a></li>
                                        </ul>
                                    </nav>
                                </div>{/* /.footer-widget__content */}
                            </div>{/* /.col-lg-2 */}
                            {/*
                      <div class="col-sm-6 col-md-6 col-lg-3 footer-widget footer-widget-nav">
                        <h6 class="footer-widget__title">Memberships</h6>
                        <div class="footer-widget__content">
                          <nav>
                            <ul class="list-unstyled">
                              <li><a href="http://www.bssuniversal.com/images/PSEB%202019-2020.jpg">Pakistan Software Export Board</a></li>
                              <li><a href="http://www.bssuniversal.com/images/P@sha-Membership-Certificate-2021-22.jpg">Pakistan Software Houses Association</a></li>
                              <li><a href="http://www.bssuniversal.com/images/LCCI%20CERTIFICATION.jpg">Lahore Chamber of Commerce & Industry</a></li>
                            </ul>
                          </nav>
                        </div>
                      </div>
          */}
                        </div>{/* /.row */}
                    </div>{/* /.footer-primary */}
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-12 text-center pb-40">
                            <span className="fz-14">© 2021 BSS Universal, All Rights Reserved.</span>
                        </div>{/* /.col-lg-12 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </footer>{/* /.Footer */}
            <button id="scrollTopBtn"><i className="fas fa-long-arrow-alt-up" /></button>
        </div>
    );
}

export default about;