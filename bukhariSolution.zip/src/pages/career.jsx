function career() {
    return (
        <div>
            {/* Mirrored from www.bssuniversal.com/career by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Dec 2022 12:28:57 GMT */}
            <meta charSet="UTF-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <meta httpEquiv="X-UA-Compatible" content="ie=edge" />
            <meta name="description" content="BSS - IT Solutions & Services Company" />
            <link href="assets/images/favicon/favicon.png" rel="icon" />
            <title>Business Solutions &amp; Services - Career</title>
            <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=Roboto:wght@400;700&display=swap" />
            <link rel="stylesheet" href="../use.fontawesome.com/releases/v5.1.1/css/all.css" />
            <link rel="stylesheet" href="assets/css/libraries.css" />
            <link rel="stylesheet" href="assets/css/style.css" />
            <div className="wrapper">
                <div className="preloader">
                    <div className="loading"><span /><span /><span /><span /></div>
                </div>{/* /.preloader */}
                {/* =========================
          Header
      =========================== */}
                <header className="header header-transparent">
                    <nav className="navbar navbar-expand-lg sticky-navbar">
                        <div className="container">
                            <a className="navbar-brand" href="/">
                                <img src="assets/images/logo/logo-light.png" className="logo-light" alt="logo" />
                                <img src="assets/images/logo/logo-dark.png" className="logo-dark" alt="logo" />
                            </a>
                            <button className="navbar-toggler" type="button">
                                <span className="menu-lines"><span /></span>
                            </button>
                            <div className="collapse navbar-collapse" id="mainNavigation">
                                <ul className="navbar-nav ml-auto">
                                    <li className="nav__item">
                                        <a href="/" className="dropdown-toggle nav__item-link">Home</a>
                                    </li>{/* /.nav-item */}
                                    <li className="nav__item has-dropdown">
                                        <a href="about-us" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Company</a>
                                        <ul className="dropdown-menu">
                                            <li className="nav__item">
                                                <a href="about-us" className="nav__item-link">About Us</a>
                                            </li>{/* /.nav-item */}
                                            <li className="nav__item">
                                                <a href="about-us" className="nav__item-link">CEO Message</a>
                                            </li>{/* /.nav-item */}
                                            <li className="nav__item">
                                                <a href="about-us" className="nav__item-link">Our Mission</a>
                                            </li>{/* /.nav-item */}
                                            <li className="nav__item">
                                                <a href="about-us" className="nav__item-link">Our Values</a>
                                            </li>{/* /.nav-item */}
                                            <li className="nav__item">
                                                <a href="about-us" className="nav__item-link">Our Team</a>
                                            </li>{/* /.nav-item */}
                                        </ul>{/* /.dropdown-menu */}
                                    </li>{/* /.nav-item */}
                                    <li className="nav__item has-dropdown">
                                        <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Services</a>
                                        <ul className="dropdown-menu">
                                            <li className="nav__item">
                                                <a href="salesforce" className="nav__item-link">CRM/Salesforce</a>
                                            </li>{/* /.nav-item */}
                                            <li className="nav__item">
                                                <a href="analytics" className="nav__item-link">BI &amp; Analytics</a>
                                            </li>{/* /.nav-item */}
                                            <li className="nav__item">
                                                <a href="digital-marketing" className="nav__item-link">Digital Marketing</a>
                                            </li>{/* /.nav-item */}
                                            <li className="nav__item">
                                                <a href="development" className="nav__item-link">Software Development</a>
                                            </li>{/* /.nav-item */}
                                            <li className="nav__item">
                                                <a href="database" className="nav__item-link">Database Development</a>
                                            </li>{/* /.nav-item */}
                                            <li className="nav__item">
                                                <a href="quality-assurance" className="nav__item-link">Quality Assurance</a>
                                            </li>{/* /.nav-item */}
                                        </ul>{/* /.dropdown-menu */}
                                    </li>{/* /.nav-item */}
                                    <li className="nav__item has-dropdown">
                                        <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Events</a>
                                        <ul className="dropdown-menu">
                                            <li className="nav__item">
                                                <a href="#" className="nav__item-link">News</a>
                                            </li>{/* /.nav-item */}
                                        </ul>{/* /.dropdown-menu */}
                                    </li>{/* /.nav-item */}
                                    <li className="nav__item has-dropdown">
                                        <a href="career" data-toggle="dropdown" className="dropdown-toggle nav__item-link active">Career</a>
                                    </li>{/* /.nav-item */}
                                    <li className="nav__item has-dropdown">
                                        <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Blog</a>
                                    </li>{/* /.nav-item */}
                                    <li className="nav__item">
                                        <a href="contact" className="nav__item-link">Contacts</a>
                                    </li>{/* /.nav-item */}
                                </ul>{/* /.navbar-nav */}
                                <button className="close-mobile-menu d-block d-lg-none"><i className="fas fa-times" /></button>
                            </div>{/* /.navbar-collapse */}
                        </div>{/* /.container */}
                    </nav>{/* /.navabr */}
                </header>{/* /.Header */}
                {/* ========================
         page title 
      =========================== */}
                <section className="page-title page-title-layout1 bg-overlay bg-overlay-gradient bg-parallax text-center">
                    <div className="bg-img"><img src="assets/images/page-titles/career.jpg" alt="background" /></div>
                    <div className="container">
                        <div className="row">
                            <div className="col-sm-12 col-md-12 col-lg-12 col-xl-6 offset-xl-3">
                                <h1 className="pagetitle__heading">Careers</h1>
                                <p className="pagetitle__desc mb-0">Passionate in taking challenges? Join BSS family and start your exceptional journey.
                                </p>
                            </div>{/* /.col-xl-6 */}
                        </div>{/* /.row */}
                    </div>{/* /.container */}
                </section>{/* /.page-title */}
                {/* ========================
       Careers
      =========================== */}
                <section id="team" className="gallery pt-130 pb-90">
                    <div className="container max-width-1300">
                        <div className="row">
                            <div className="col-sm-12 col-md-12 col-lg-12 col-xl-6">
                                <div className="gallery-images-wrapper">
                                    <a className="popup-gallery-item" href="assets/images/gallery/1.jpg">
                                        <img src="assets/images/gallery/1.jpg" alt="gallery img" />
                                    </a>
                                    <a className="popup-gallery-item" href="assets/images/gallery/2.jpg">
                                        <img src="assets/images/gallery/2.jpg" alt="gallery img" />
                                    </a>
                                    <a className="popup-gallery-item" href="assets/images/gallery/3.jpg">
                                        <img src="assets/images/gallery/3.jpg" alt="gallery img" />
                                    </a>
                                    <a className="popup-gallery-item" href="assets/images/gallery/4.jpg">
                                        <img src="assets/images/gallery/4.jpg" alt="gallery img" />
                                    </a>
                                </div>{/* /.gallery-images-wrapper */}
                            </div>{/* /.col-xl-5 */}
                            <div className="col-sm-12 col-md-12 col-lg-12 col-xl-5 offset-xl-1">
                                <div className="sticky-top">
                                    <h2 className="heading__subtitle">We Prepare For The Future.</h2>
                                    <h3 className="heading__title">Improve Efficiency And Provide Better Experiences!</h3>
                                    <p>We are enthusiastic about our clients, they are at the core of what we do. If you are passionate in taking challenges and are anxious to fill in a fast workplace then you need to reach out to us! Join BSS family and start your exceptional journey.</p>
                                    <p>We guarantee, you will come across, uniquely productive trials and get a good chance to polish your technical and leadership skills.</p>
                                </div>
                            </div>{/* /.col-xl-7 */}
                        </div>{/* /.row */}
                    </div>{/* /.container */}
                </section>{/* /.Careers */}
                {/* ========================= 
           Job Opeing
      =========================  */}
                <section className="careers">
                    <div className="container">
                        <div className="row">
                            <h5>Business Solutions &amp; Services is urgently hiring for multiple locations.</h5>
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Jr. Technical Consultant - BI</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> Good concepts of BI, knowledge of SQL queries, should know about the tools and technologies used to develop BI reports like Power BI, Qlik, SSRS, etc. Adaptable and willing to learn new techniques. Excellent communication skills. Graduates in computer science having 1-2 Years of experience are encouraged to apply</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Sr. Business Analyst</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> 4-5 years are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Business Analyst</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> 2-3 years are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Custom App Developers</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> 2-3 years are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Jr. Software Engineer-Business Intelligence</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> Fresh CS Graduates are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Jr. Software Engineer-UI/UX</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> Diploma Holders Fresh are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Software Engineer-UI/UX</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> 1-3 years of Experience are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">DBA and Developer</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> 2-3 years of experience are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Jr. DBA</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> Fresh CS Graduates are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Sr. Mobile Dev – Flutter</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> 2-3 years of experience are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Jr. Mobile Dev – Flutter</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> Fresh CS Graduates are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Project Managers</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> 4-5 years of experience are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Sr. QA</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> 5-6 years of experience are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">QA</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> 2-3 years of experience are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Jr. QA</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> Fresh CS Graduates are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Salesforce Admin</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> Business Graduates are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                            <div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Sr. Salesforce Developer</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> 4-5 years of experience are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}<div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Salesforce Developer</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> 2-3 years of experience are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}<div className="col-12">
                                <div className="jobs-container">
                                    {/* career item #1 */}
                                    <div className="job-item">
                                        <div className="row">
                                            <div className="col-sm-12 col-md-12 col-lg-4">
                                                <div className="job__meta">
                                                    <span className="job__type">Full Time</span>
                                                    {/*                                            <span class="job__location">Lahore / Karachi</span>*/}
                                                </div>
                                                <h4 className="job__title">Jr. Salesforce Developer</h4>
                                            </div>{/* /.col-lg-4 */}
                                            <div className="col-sm-12 col-md-12 col-lg-5">
                                                <p className="job__desc"><b>Requirements:</b> Fresh CS Graduates are encouraged to apply – Multiple Positions, Location: Lahore/Karachi</p>
                                            </div>{/* /.col-lg-5 */}
                                            <div className="col-sm-12 col-md-12 col-lg-3 d-flex align-items-center justify-content-end btn-wrap secondary-nav-internal-navigation">
                                                <a href="#" data-scroll="contactForm" className="btn btn__secondary nav__link">Apply Now</a>
                                            </div>{/* /.col-lg-3 */}
                                        </div>{/* /.row */}
                                    </div>{/* /.job-item */}
                                </div>
                            </div>{/* /.col-lg-12 */}
                        </div>{/* /.row */}
                    </div>{/* /.container */}
                </section>{/* /.Job Opeing */}
                {/* ==========================
          contact box
      =========================== */}
                <section className="contact-layout1 pt-0 mt--100">
                    <div className="container">
                        <div className="row">
                            <div className="col-12">
                                <div className="contact-panel d-flex flex-wrap">
                                    <div className="contact-panel__info">
                                        <div className="bg-img"><img src="assets/images/backgrounds/4.jpg" alt="banner" /></div>
                                    </div>
                                    <form className="contact-panel__form" method="post" action="https://www.bssuniversal.com/assets/php/contact.php" id="contactForm">
                                        <div className="row">
                                            <div className="col-sm-12">
                                                <h4 className="contact-panel__title">Join us at BSS</h4>
                                                <p className="contact-panel__desc mb-20">Send us your resume to become part of a team that knows nothing but winning.</p>
                                            </div>
                                            <div className="col-sm-12 col-md-12 col-lg-12">
                                                <div className="form-group">
                                                    {/*<input type="text" class="form-control" placeholder="Select Job" id="contact-name" name="contact-name"
                          required>*/}
                                                    <select className="form-control custom-select" required>
                                                        <option disabled selected="true">=== SELECT JOB ===</option>
                                                        <option value={1}>Jr.Technical Consultant</option>
                                                        <option value={2}>Technical Consultant</option>
                                                        <option value={3}>Sr.Technical Consultant</option>
                                                        <option value={4}>Quality Assurance Engineer</option>
                                                        <option value={5}>Jr.Quality Assurance Engineer</option>
                                                        <option value={5}>Sr.Quality Assurance Engineer</option>
                                                        <option value={6}>Business Analyst</option>
                                                        <option value={7}>UI/UX Developer</option>
                                                        <option value={8}>Jr. UI/UX Developer</option>
                                                        <option value={9}>Functional Consutant SFDC</option>
                                                        <option value={10}>Jr.Technical Consultant SFDC</option>
                                                        <option value={11}>Technical Consultant SFDC</option>
                                                        <option value={12}>Sr.Technical Consultant SFDC</option>
                                                        <option value={13}>Sr. Mobile Dev – Flutter</option>
                                                        <option value={14}>Jr. Mobile Dev – Flutter</option>
                                                        <option value={15}>Sr. Business Analyst</option>
                                                        <option value={16}>Business Analyst</option>
                                                        <option value={17}>Custom App Developers</option>
                                                        <option value={18}>Jr. Software Engineer-Business Intelligence</option>
                                                        <option value={19}>DBA And Developer</option>
                                                        <option value={20}>Jr. DBA</option>
                                                        <option value={21}>Project Managers</option>
                                                        <option value={22}>Salesforce Developer</option>
                                                        <option value={23}>Sr.Salesforce Developer</option>
                                                        <option value={24}>Jr. Salesforce Developer</option>
                                                    </select>
                                                </div>
                                            </div>{/* /.col-lg-6 */}
                                            <div className="col-sm-6 col-md-6 col-lg-6">
                                                <div className="form-group">
                                                    <input type="text" className="form-control" placeholder="Enter your name here" id="contact-Phone" name="contact-phone" required />
                                                </div>
                                            </div>{/* /.col-lg-6 */}
                                            <div className="col-sm-6 col-md-6 col-lg-6">
                                                <div className="form-group">
                                                    <input type="email" className="form-control" placeholder="Enter your email here" id="contact-website" name="contact-website" required />
                                                </div>
                                            </div>{/* /.col-lg-6 */}
                                            <div className="col-12">
                                                <div className="form-group">
                                                    <label htmlFor="exampleFormControlFile1">ATTACH FILE (.DOCX OR .PDF FILE)</label>
                                                    <input type="file" className="form-control-file" id="exampleFormControlFile1" />
                                                    {/*<input id="cv-file-input" type="file" class="custom-file-input" name="file" value="" placeholder="">
                                              <label class="custom-file-label text-left">ATTACH FILE</label>*/}
                                                </div>
                                                <button type="submit" className="btn btn__primary btn__icon btn__xhight mt-10">
                                                    <span>Apply Now</span> <i className="icon-arrow-right" />
                                                </button>
                                                <div className="contact-result" />
                                            </div>{/* /.col-lg-12 */}
                                        </div>{/* /.row */}
                                    </form>
                                </div>
                            </div>{/* /.col-lg-6 */}
                        </div>{/* /.row */}
                    </div>{/* /.container */}
                </section>{/* /.contact box */}
                {/* ========================
       Counters
      =========================== */}
                <section className="counters pt-60">
                    <div className="container">
                        <div className="row">
                            {/* counter item #1 */}
                            <div className="col-sm-6 col-md-3 col-lg-3">
                                <div className="counter-item">
                                    <h4 className="counter">1,311</h4>
                                    <p className="counter__desc">Projects And Software Developed Till 2021</p>
                                </div>{/* /.counter-item */}
                            </div>{/* /.col-lg-3 */}
                            {/* counter item #2 */}
                            <div className="col-sm-6 col-md-3 col-lg-3">
                                <div className="counter-item">
                                    <h4 className="counter">115</h4>
                                    <p className="counter__desc">Qualified Employees And Developers With Us</p>
                                </div>{/* /.counter-item */}
                            </div>{/* /.col-lg-3 */}
                            {/* counter item #3 */}
                            <div className="col-sm-6 col-md-3 col-lg-3">
                                <div className="counter-item">
                                    <h4 className="counter">5,200</h4>
                                    <p className="counter__desc">Satisfied Users We Have Served Globally</p>
                                </div>{/* /.counter-item */}
                            </div>{/* /.col-lg-3 */}
                            {/* counter item #4 */}
                            <div className="col-sm-6 col-md-3 col-lg-3">
                                <div className="counter-item">
                                    <h4 className="counter">15</h4>
                                    <p className="counter__desc">Years Of Experience In The IT &amp; Software Industry</p>
                                </div>{/* /.counter-item */}
                            </div>{/* /.col-lg-3 */}
                        </div>{/* /.row */}
                    </div>{/* /.container */}
                </section>{/* /.counters */}
                {/* ========================
          Footer
        ========================== */}
                <footer className="footer bg-secondary">
                    <div className="container">
                        <div className="footer-top pt-50 pb-30">
                            <div className="row">
                                <div className="col-sm-4 col-md-2 col-lg-4">
                                    <img src="assets/images/logo/logo-light-small.png" alt="logo" className="mb-30" />
                                </div>{/* /.col-lg-2 */}
                                <div className="col-sm-8 col-md-4 col-lg-3">
                                    <h6 className="footer-top__title">Sign up for latest IT resources,
                                        news and insights from BSS!</h6>
                                </div>{/* /.col-lg-3 */}
                                <div className="col-sm-12 col-md-6 col-lg-5">
                                    <form className="footer-form d-flex mb-0">
                                        <input type="email" className="form-control mr-20" placeholder="Your Email Address" />
                                        <button type="submit" className="btn btn__primary btn__primary-style2">
                                            <span>Subscribe</span>
                                            <i className="icon-arrow-right" />
                                        </button>
                                    </form>
                                </div>{/* /.col-lg-6 */}
                            </div>{/* /.row */}
                        </div>{/* /.footer-top */}
                        <div className="footer-primary">
                            <div className="row">
                                <div className="col-sm-12 col-md-12 col-lg-4 footer-widget footer-widget-about">
                                    <div className="footer-widget__content">
                                        <div className="contact-info">
                                            <h6 className="footer-widget__title">Quick Contact</h6>
                                            <ul className="contact-list list-unstyled">
                                                <li className="color-gray">If you have any questions or need help, feel free to contact with our team.
                                                </li>
                                                <li className="mt-20 mb-20">
                                                    <a href="mailto:consult@bssuniversal.com" className="phone-number">
                                                        <span>consult@bssuniversal.com</span>
                                                    </a>
                                                </li>
                                                <li className="color-body"><a href="contact">Dubai | United States | Pakistan</a></li>
                                            </ul>
                                        </div>{/* /.contact-info */}
                                        <ul className="social-icons list-unstyled mb-0">
                                            <li><a href="https://www.facebook.com/bssuniversal" target="_blank"><i className="fab fa-facebook-f" /></a></li>
                                            <li><a href="https://www.linkedin.com/company/bssuniversal/" target="_blank"><i className="fab fa-linkedin" /></a></li>
                                            <li><a href="https://twitter.com/bssuniversal" target="_blank"><i className="fab fa-twitter" /></a></li>
                                            <li><a href="https://www.instagram.com/bss.global12/?hl=en" target="_blank"><i className="fab fa-instagram" /></a></li>
                                        </ul>{/* /.social-icons */}
                                    </div>{/* /.footer-widget__content */}
                                </div>{/* /.col-xl-2 */}
                                <div className="col-sm-6 col-md-6 col-lg-3 offset-lg-1 footer-widget footer-widget-nav">
                                    <h6 className="footer-widget__title">Company</h6>
                                    <div className="footer-widget__content">
                                        <nav>
                                            <ul className="list-unstyled">
                                                <li><a href="about-us">About Us</a></li>
                                                <li><a href="about-us">Our Team</a></li>
                                                <li><a href="#">Event &amp; News</a></li>
                                                <li><a href="#">Blog &amp; Article</a></li>
                                                <li><a href="career">Career</a></li>
                                                <li><a href="contact">Contacts</a></li>
                                            </ul>
                                        </nav>
                                    </div>{/* /.footer-widget__content */}
                                </div>{/* /.col-lg-2 */}
                                <div className="col-sm-6 col-md-6 col-lg-4 footer-widget footer-widget-nav">
                                    <h6 className="footer-widget__title">Solutions</h6>
                                    <div className="footer-widget__content">
                                        <nav>
                                            <ul className="list-unstyled">
                                                <li><a href="salesforce">CRM/Salesforce</a></li>
                                                <li><a href="analytics">BI &amp; Analytics</a></li>
                                                <li><a href="digital-marketing">Digital Marketing</a></li>
                                                <li><a href="development">Software Development</a></li>
                                                <li><a href="database">Database Development</a></li>
                                                <li><a href="quality-assurance">Quality Assurance</a></li>
                                            </ul>
                                        </nav>
                                    </div>{/* /.footer-widget__content */}
                                </div>{/* /.col-lg-2 */}
                                {/*
              <div class="col-sm-6 col-md-6 col-lg-3 footer-widget footer-widget-nav">
                <h6 class="footer-widget__title">Memberships</h6>
                <div class="footer-widget__content">
                  <nav>
                    <ul class="list-unstyled">
                      <li><a href="http://www.bssuniversal.com/images/PSEB%202019-2020.jpg">Pakistan Software Export Board</a></li>
                      <li><a href="http://www.bssuniversal.com/images/P@sha-Membership-Certificate-2021-22.jpg">Pakistan Software Houses Association</a></li>
                      <li><a href="http://www.bssuniversal.com/images/LCCI%20CERTIFICATION.jpg">Lahore Chamber of Commerce & Industry</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
  */}
                            </div>{/* /.row */}
                        </div>{/* /.footer-primary */}
                        <div className="row">
                            <div className="col-sm-12 col-md-12 col-lg-12 text-center pb-40">
                                <span className="fz-14">© 2021 BSS Universal, All Rights Reserved.</span>
                            </div>{/* /.col-lg-12 */}
                        </div>{/* /.row */}
                    </div>{/* /.container */}
                </footer>{/* /.Footer */}
                <button id="scrollTopBtn"><i className="fas fa-long-arrow-alt-up" /></button>
            </div>{/* /.wrapper */}
            {/*  */}
            {/* Mirrored from www.bssuniversal.com/career by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Dec 2022 12:28:57 GMT */}
        </div>
    );
}

export default career;