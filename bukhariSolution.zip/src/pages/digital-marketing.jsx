function digitalmarketing() {

    return (
        <div className="wrapper">
            <div className="preloader">
                <div className="loading"><span /><span /><span /><span /></div>
            </div>{/* /.preloader */}
            {/* =========================
  Header
    =========================== */}
            <header className="header header-transparent">
                <nav className="navbar navbar-expand-lg sticky-navbar">
                    <div className="container">
                        <a className="navbar-brand" href="/">
                            <img src="assets/images/logo/logo-light.png" className="logo-light" alt="logo" />
                            <img src="assets/images/logo/logo-dark.png" className="logo-dark" alt="logo" />
                        </a>
                        <button className="navbar-toggler" type="button">
                            <span className="menu-lines"><span /></span>
                        </button>
                        <div className="collapse navbar-collapse" id="mainNavigation">
                            <ul className="navbar-nav ml-auto">
                                <li className="nav__item">
                                    <a href="/" className="dropdown-toggle nav__item-link">Home</a>
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Company</a>
                                    <ul className="dropdown-menu">
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">About Us</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">CEO Message</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">Our Mission</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">Our Values</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">Our Team</a>
                                        </li>{/* /.nav-item */}
                                    </ul>{/* /.dropdown-menu */}
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Services</a>
                                    <ul className="dropdown-menu">
                                        <li className="nav__item">
                                            <a href="salesforce" className="nav__item-link">CRM/Salesforce</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="analytics" className="nav__item-link">BI &amp; Analytics</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="digital-marketing" className="nav__item-link">Digital Marketing</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="development" className="nav__item-link">Software Development</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="database" className="nav__item-link">Database Development</a>
                                        </li>{/* /.nav-item */}
                                        <li className="nav__item">
                                            <a href="quality-assurance" className="nav__item-link">Quality Assurance</a>
                                        </li>{/* /.nav-item */}
                                    </ul>{/* /.dropdown-menu */}
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Events</a>
                                    <ul className="dropdown-menu">
                                        <li className="nav__item">
                                            <a href="#" className="nav__item-link">News</a>
                                        </li>{/* /.nav-item */}
                                    </ul>{/* /.dropdown-menu */}
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="career" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Career</a>
                                </li>{/* /.nav-item */}
                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Blog</a>
                                </li>{/* /.nav-item */}
                                <li className="nav__item">
                                    <a href="contact" className="nav__item-link">Contacts</a>
                                </li>{/* /.nav-item */}
                            </ul>{/* /.navbar-nav */}
                            <button className="close-mobile-menu d-block d-lg-none"><i className="fas fa-times" /></button>
                        </div>{/* /.navbar-collapse */}
                    </div>{/* /.container */}
                </nav>{/* /.navabr */}
            </header>{/* /.Header */}
            {/* ========================
 page title 
    =========================== */}
            <section className="page-title page-title-layout1 bg-overlay bg-overlay-gradient bg-parallax text-center">
                <div className="bg-img"><img src="assets/images/page-titles/digital.jpg" alt="background" /></div>
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-12 col-xl-6 offset-xl-3">
                            <h1 className="pagetitle__heading_s">Digital Marketing</h1>
                            <p className="pagetitle__desc mb-0">committed to offering 360˚ digital marketing services that create identities.
                            </p>
                        </div>{/* /.col-xl-6 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.page-title */}
            {/* ========================
Secondary Nav
    =========================== */}
            <section className="secondary-nav sticky-top py-0">
                <div className="container">
                    <div className="row">
                        <div className="col-12">
                            <nav className="nav nav-tabs justify-content-center">
                                <a href="salesforce" className="nav__link">CRM/Salesforce</a>
                                <a href="analytics" className="nav__link">BI &amp; Analytics</a>
                                <a href="digital-marketing" className="nav__link active">Digital Marketing</a>
                                <a href="development" className="nav__link">Software Development</a>
                                <a href="database" className="nav__link">Database Development</a>
                                <a href="quality-assurance" className="nav__link">Quality Assurance</a>
                            </nav>
                        </div>{/* /.col-12 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.Secondary Nav */}
            {/* ======================
    Digital Marketing
    ========================= */}
            <section id="overview" className="features-layout3 pt-130 pb-130">
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-7 col-xl-6">
                            <div className="heading heading-layout2 mb-50">
                                <h2 className="heading__subtitle">We can help you throughout your digital journey</h2>
                                <h3 className="heading__title_s">We merge imagination and technology to help brands grow in an age of digital transformation.
                                </h3>
                                <p className="heading__desc mb-30">In today’s digital business world, you need a partner who can help you take advantage of marketing opportunities across a variety of channels in real-time. BSS combines a data-driven approach with knowledge gained from years in digital marketing to deliver outstanding results to our clients.
                                </p>
                                <p className="heading__desc mb-30">We always stand at the forefront of all emerging trends in digital marketing. We deliver custom Digital Marketing Solutions with an understanding of a different set of challenges and unique requirements of every business. Our main strategy is to help our clients to improve their operational performance and grow their businesses by delivering their products and services more effectively &amp; efficiently in existing &amp; new markets.
                                </p>
                            </div>
                            <div className="row">
                                <div className="col-12">
                                    <div className="cta-banner mt-50 mb-30 d-flex flex-wrap align-items-center">
                                        <h4 className="cta__title pr-30">Ready To Make a Real Change? Let’s Build this Thing Together! You can connect with us any time <a href="#" />
                                        </h4>
                                        <a href="contact" className="btn btn__primary">Contact Us</a>
                                    </div>{/* /.cta-banner */}
                                </div>{/* /.col-12 */}
                            </div>{/* /.row */}
                        </div>{/* /.col-xl-5 */}
                        <div className="col-sm-12 col-md-12 col-lg-5 col-xl-5 offset-xl-1">
                            <div className="sticky-top">
                                <img src="assets/images/about/10.jpg" alt="banner" />
                            </div>
                        </div>{/* /col-lg-5 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.Digital Marketing */}
            {/* =========================
 Website Dev
=========================== */}
            <section className="banner-layout2 py-0 bg-secondary">
                <div className="container-fluid px-0">
                    <div className="row row-no-gutter align-items-center">
                        <div className="col-sm-12 col-md-12 col-lg-6">
                            <div className="banner-text inner-padding">
                                <div className="heading-layout2 mb-60">
                                    <h2 className="heading__subtitle">Website design that reflects your brand.</h2>
                                    <h3 className="heading__title color-white mb-30">The technical skill and battle-tested processes to deliver high-performing websites.</h3>
                                    <p className="heading__desc">BSS specializes in website design and development services. Our web experiences are high-performing, feature-packed and digitally transformative, designed to be user-friendly, fully functional, very secure and able to scale as your enterprise grows.
                                    </p>
                                </div>{/* /.heading */}
                                <div className="row fancybox-light">
                                    <div className="col-sm-6">
                                        {/* fancybox item #1 */}
                                        <div className="fancybox-item">
                                            <div className="fancybox__icon">
                                                <i className="icon-website" />
                                            </div>{/* /.fancybox__icon */}
                                            <div className="fancybox__content">
                                                <h4 className="fancybox__title">Website Design</h4>
                                                <p className="fancybox__desc">Specializing in creating highly performing sites for mid-market to enterprise businesses.</p>
                                            </div>{/* /.fancybox-content */}
                                        </div>{/* /.fancybox-item */}
                                    </div>{/* /.col-lg-3 */}
                                    <div className="col-sm-6">
                                        {/* fancybox item #2 */}
                                        <div className="fancybox-item">
                                            <div className="fancybox__icon">
                                                <i className="icon-programming" />
                                            </div>{/* /.fancybox__icon */}
                                            <div className="fancybox__content">
                                                <h4 className="fancybox__title">Website Development</h4>
                                                <p className="fancybox__desc">Step inside the center of excellence where we build bold, engaging new websites.
                                                </p>
                                            </div>{/* /.fancybox-content */}
                                        </div>{/* /.fancybox-item */}
                                    </div>{/* /.col-lg-3 */}
                                </div>{/* /.row */}
                            </div>
                        </div>{/* /.col-xl-6 */}
                        <div className="col-sm-12 col-md-12 col-lg-6">
                            <div className="banner-img">
                                <img src="assets/images/banners/3.jpg" alt="banner" className="w-100" />
                            </div>
                        </div>{/* /.col-xl-6 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.Website Dev */}
            {/* ========================
Graphic Design
    =========================== */}
            <section id="message" className="about-layout1 pb-130">
                <div className="container">
                    <div className="row align-items-end">
                        <div className="col-sm-12 col-md-12 col-lg-6 col-xl-5">
                            <div className="about__img">
                                <img src="assets/images/about/12.jpg" alt="about" />
                            </div>{/* /.about-img */}
                        </div>{/* /.col-xl-5 */}
                        <div className="col-sm-12 col-md-12 col-lg-6 col-xl-6 offset-xl-1">
                            <div className="heading-layout2">
                                <h2 className="heading__subtitle">Creative Graphic Designs</h2>
                                <h3 className="heading__title mb-30">There’s no limit to what you can get designed at BSS</h3>
                            </div>{/* /heading */}
                            <div className="about__Text">
                                <p className="mb-30">Our Graphic Design experts at BSS make sure that the design we create is stunning, eye-catching, unique, and perfectly designed &amp; crafted according to your business requirements. When it comes to graphic designing services, we believe the design should be trendy and should resemble the brand &amp; image of the business correctly. It is, therefore, our experts always use the latest graphic design tools, techniques &amp; strategies to exceed your expectations.</p>
                                <p className="mb-30">Whether you’re looking for a spectacular new logo or some stunning flyers, the talented designers at BSS can make it happen. We pride ourselves on its high-quality designers who deliver only the best graphic design services. Select your desire design service below and get the design you’ll love today!</p>
                                <ul className="list-items list-items-layout2 list-unstyled mb-40">
                                    <li>Logo Design</li>
                                    <li>Business Card Design</li>
                                    <li>Brochure Design</li>
                                    <li>Landing Page Design</li>
                                    <li>Newsletter Design</li>
                                    <li>Brand Collateral</li>
                                    <li>Social Media Content Design</li>
                                </ul>
                            </div>
                        </div>{/* /.col-xl-7 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.Graphic Design */}
            {/* ======================
    CLM
    ========================= */}
            <section id="overview" className="features-layout3 pt-130 pb-130">
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-7 col-xl-6">
                            <div className="heading heading-layout2 mb-50">
                                <h2 className="heading__subtitle">Closed Loop Marketing</h2>
                                <h3 className="heading__title_s">Half the money I spend on marketing is wasted; the trouble is I don’t know which half.
                                </h3>
                                <p className="heading__desc mb-30">Enable the CLM to uplift what happens in the market!! CLM will help you complete the marketing loop with real-time analytical feedback.
                                </p>
                                <p className="heading__desc mb-30">Imagine a world where the most successful promotional message for a drug is written by a nurse practitioner. Where independent sales reps will sell their services to companies that need them. Where physicians questioned are answered even before they asked. Where anyone can learn anything they want to know about a product from anywhere, at any time…where pharma companies spend less on marketing but get higher awareness of their products.
                                </p>
                                <p className="heading__desc mb-30">3 key pillars:
                                </p>
                                <ul className="list-items list-items-layout2 list-unstyled mb-40">
                                    <li>Personalization – giving the customer a personalized message</li>
                                    <li>Analytics – learning from what the customer tells you</li>
                                    <li>Responsiveness – evolving the con to prove you were listening</li>
                                </ul>
                            </div>
                            <div className="row">
                                <div className="col-12">
                                    <div className="cta-banner mt-50 mb-30 d-flex flex-wrap align-items-center">
                                        <h4 className="cta__title pr-30 font_lower">Ready To Make a Real Change? Let’s Build this Thing Together! You can connect with us any time<br /><a href="#" />
                                        </h4>
                                        <a href="contact" className="btn btn__primary">Contact Us</a>
                                    </div>{/* /.cta-banner */}
                                </div>{/* /.col-12 */}
                            </div>{/* /.row */}
                        </div>{/* /.col-xl-5 */}
                        <div className="col-sm-12 col-md-12 col-lg-5 col-xl-5 offset-xl-1">
                            <div className="sticky-top">
                                <img src="assets/images/about/13.jpg" alt="banner" />
                            </div>
                        </div>{/* /col-lg-5 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.CLM */}
            {/* ======================
     Work Process 
    ========================= */}
            <section id="work-process" className="work-process pt-130 pb-130">
                <div className="bg-img"><img src="assets/images/backgrounds/2.jpg" alt="background" /></div>
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-6 col-xl-7">
                            <div className="banners-wrapper sticky-top">
                                <div className="tab-content mb-50">
                                    <div className="tab-pane fade show active" id="tab1">
                                        <div className="video__banner">
                                            <img src="assets/images/work-process/1.jpg" className="rounded" alt="banner" />
                                        </div>{/* /.video__banner */}
                                    </div>
                                    <div className="tab-pane fade" id="tab2">
                                        <div className="video__banner">
                                            <img src="assets/images/work-process/2.jpg" className="rounded" alt="banner" />
                                        </div>{/* /.video__banner */}
                                    </div>
                                    <div className="tab-pane fade" id="tab3">
                                        <div className="video__banner">
                                            <img src="assets/images/work-process/3.jpg" className="rounded" alt="banner" />
                                        </div>{/* /.video__banner */}
                                    </div>
                                    <div className="tab-pane fade" id="tab4">
                                        <div className="video__banner">
                                            <img src="assets/images/work-process/4.jpg" className="rounded" alt="banner" />
                                        </div>{/* /.video__banner */}
                                    </div>
                                </div>{/* /.tab-content */}
                                <div className="cta-banner mt-30 mb-30 d-flex flex-wrap align-items-center">
                                    <h4 className="cta__title my-3 pr-30 font_lower">
                                        Our core focus is to provide Quality services enabling our clients to focus on their core business. Ready to start your next
                                        project? Drop us a line or two at: <a href="mailto:consult@bssuniversal.com">consult@bssuniversal.com</a>
                                    </h4>
                                    <a href="contact" className="btn btn__primary btn__primary-style2">
                                        <span>Request Demo</span>
                                        <i className="icon-arrow-right" />
                                    </a>
                                </div> {/* /.cta-banner */}
                            </div>
                        </div>{/* /.col-lg-7 */}
                        <div className="col-sm-12 col-md-12 col-lg-6 col-xl-5">
                            <div className="heading mb-70">
                                <h2 className="heading__subtitle color-primary">How We Works!!</h2>
                                <h3 className="heading__title color-white">Deliver Only Exceptional Quality, And Improve! </h3>
                            </div>
                            <nav className="nav nav-tabs">
                                {/* process Item #1 */}
                                <a className="process-item active" data-toggle="tab" href="#tab1">
                                    <div className="process-item__content">
                                        <h4 className="process-item__title">Brainstorming</h4>
                                        <p className="process-item__desc">The first step is to take the projects data &amp; think about it to manage
                                            all aspects of your software assets including maintenance.</p>
                                    </div>
                                </a>{/* /.process-item */}
                                {/* process Item #2 */}
                                <a className="process-item" data-toggle="tab" href="#tab2">
                                    <div className="process-item__content">
                                        <h4 className="process-item__title">Concept Prototype</h4>
                                        <p className="process-item__desc">To know about the product, customers &amp; competitors offer integral
                                            communication services software assets.
                                        </p>
                                    </div>
                                </a>{/* /.process-item */}
                                {/* process Item #3 */}
                                <a className="process-item" data-toggle="tab" href="#tab3">
                                    <div className="process-item__content">
                                        <h4 className="process-item__title">Design Layout</h4>
                                        <p className="process-item__desc">Start to work on the design taking with collected data, we're
                                            responsible for our process and results.
                                        </p>
                                    </div>
                                </a>{/* /.process-item */}
                                {/* process Item #4 */}
                                <a className="process-item" data-toggle="tab" href="#tab4">
                                    <div className="process-item__content">
                                        <h4 className="process-item__title">Evaluation</h4>
                                        <p className="process-item__desc">Reach a conclusion from the investigations about the product and we thank
                                            each of our great clients projects.</p>
                                    </div>
                                </a>{/* /.process-item */}
                            </nav>
                        </div>{/* /.col-lg-5 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.Work Process */}
            {/* =========================
 Banner layout 1
=========================== */}
            <section id="banner" className="banner-layout1 pt-130 bg-overlay bg-overlay-primary">
                <div className="bg-img"><img src="assets/images/banners/4.jpg" alt="background" /></div>
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-12 col-xl-5 d-flex flex-column justify-content-between">
                            <div>
                                <div className="heading heading-light mb-50">
                                    <h2 className="heading__subtitle">Ensure High Availability of Your Services</h2>
                                    <h3 className="heading__title mb-30">We provide excellent IT support services to all our customers 24/7.
                                    </h3>
                                    <p className="heading__desc">Whichever level of support you require, you can be assured of the prompt attention of a professional and experienced team who will work to enhance business performance and continuity.
                                    </p>
                                </div>{/* /.heading */}
                                <div className="d-flex flex-wrap mb-60">
                                    <a href="#" className="btn btn__white mr-30">
                                        <i className="icon-arrow-right" />
                                        <span>Contact Us</span>
                                    </a>
                                    <a href="about-us" className="btn btn__white btn__outlined">About Us</a>
                                </div>
                            </div>
                            <ul className="list-items list-items-layout2 list-items-light list-unstyled">
                                <li>Delivered in more than 1,311 Project interactions </li>
                                <li>Promote transparency, respect and diversity</li>
                                <li>Creating long term win-win relationship</li>
                            </ul>
                        </div>{/* /.col-xl-6 */}
                        <div className="col-sm-12 col-md-12 col-lg-12 col-xl-7">
                            <div className="contact-panel">
                                <form className="contact-panel__form" method="post" action="https://www.bssuniversal.com/assets/php/contact.php" id="contactForm">
                                    <div className="row">
                                        <div className="col-sm-12">
                                            <h4 className="contact-panel__title">Request A Quote</h4>
                                            <p className="contact-panel__desc mb-20">Our highly experienced and certified engineers and IT staff are ready to
                                                help you to keep your IT business safe &amp; ensure high availability.</p>
                                        </div>
                                        <div className="col-sm-6 col-md-6 col-lg-6">
                                            <div className="form-group">
                                                <input type="text" className="form-control" placeholder="Name" id="contact-name" name="contact-name" required />
                                            </div>
                                        </div>{/* /.col-lg-6 */}
                                        <div className="col-sm-6 col-md-6 col-lg-6">
                                            <div className="form-group">
                                                <input type="email" className="form-control" placeholder="Email" id="contact-email" name="contact-email" required />
                                            </div>
                                        </div>{/* /.col-lg-6 */}
                                        <div className="col-sm-6 col-md-6 col-lg-6">
                                            <div className="form-group">
                                                <select className="form-control">
                                                    <option value={1}>Inquiry</option>
                                                    <option value={2}>case study</option>
                                                </select>
                                            </div>
                                        </div>{/* /.col-lg-6 */}
                                        <div className="col-sm-6 col-md-6 col-lg-6">
                                            <div className="form-group">
                                                <input type="text" className="form-control" placeholder="Phone" id="contact-Phone" name="contact-phone" required />
                                            </div>
                                        </div>{/* /.col-lg-6 */}
                                        <div className="col-12">
                                            <div className="form-group">
                                                <textarea className="form-control" placeholder="Describe your inquirey!" id="contact-message" name="contact-message" defaultValue={""} />
                                            </div>
                                            <button type="submit" className="btn btn__primary btn__block btn__xhight mt-10">
                                                <span>Submit Request</span> <i className="icon-arrow-right" />
                                            </button>
                                            <div className="contact-result" />
                                        </div>{/* /.col-lg-12 */}
                                    </div>{/* /.row */}
                                </form>
                            </div>
                        </div>{/* /.col-xl-6 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </section>{/* /.Banner layout 1 */}
            {/* ========================
  Footer
========================== */}
            <footer className="footer bg-secondary">
                <div className="container">
                    <div className="footer-top pt-50 pb-30">
                        <div className="row">
                            <div className="col-sm-4 col-md-2 col-lg-4">
                                <img src="assets/images/logo/logo-light-small.png" alt="logo" className="mb-30" />
                            </div>{/* /.col-lg-2 */}
                            <div className="col-sm-8 col-md-4 col-lg-3">
                                <h6 className="footer-top__title">Sign up for latest IT resources,
                                    news and insights from BSS!</h6>
                            </div>{/* /.col-lg-3 */}
                            <div className="col-sm-12 col-md-6 col-lg-5">
                                <form className="footer-form d-flex mb-0">
                                    <input type="email" className="form-control mr-20" placeholder="Your Email Address" />
                                    <button type="submit" className="btn btn__primary btn__primary-style2">
                                        <span>Subscribe</span>
                                        <i className="icon-arrow-right" />
                                    </button>
                                </form>
                            </div>{/* /.col-lg-6 */}
                        </div>{/* /.row */}
                    </div>{/* /.footer-top */}
                    <div className="footer-primary">
                        <div className="row">
                            <div className="col-sm-12 col-md-12 col-lg-4 footer-widget footer-widget-about">
                                <div className="footer-widget__content">
                                    <div className="contact-info">
                                        <h6 className="footer-widget__title">Quick Contact</h6>
                                        <ul className="contact-list list-unstyled">
                                            <li className="color-gray">If you have any questions or need help, feel free to contact with our team.
                                            </li>
                                            <li className="mt-20 mb-20">
                                                <a href="mailto:consult@bssuniversal.com" className="phone-number">
                                                    <span>consult@bssuniversal.com</span>
                                                </a>
                                            </li>
                                            <li className="color-body"><a href="contact">Dubai | United States | Pakistan</a></li>
                                        </ul>
                                    </div>{/* /.contact-info */}
                                    <ul className="social-icons list-unstyled mb-0">
                                        <li><a href="https://www.facebook.com/bssuniversal" target="_blank"><i className="fab fa-facebook-f" /></a></li>
                                        <li><a href="https://www.linkedin.com/company/bssuniversal/" target="_blank"><i className="fab fa-linkedin" /></a></li>
                                        <li><a href="https://twitter.com/bssuniversal" target="_blank"><i className="fab fa-twitter" /></a></li>
                                        <li><a href="https://www.instagram.com/bss.global12/?hl=en" target="_blank"><i className="fab fa-instagram" /></a></li>
                                    </ul>{/* /.social-icons */}
                                </div>{/* /.footer-widget__content */}
                            </div>{/* /.col-xl-2 */}
                            <div className="col-sm-6 col-md-6 col-lg-3 offset-lg-1 footer-widget footer-widget-nav">
                                <h6 className="footer-widget__title">Company</h6>
                                <div className="footer-widget__content">
                                    <nav>
                                        <ul className="list-unstyled">
                                            <li><a href="about-us">About Us</a></li>
                                            <li><a href="about-us">Our Team</a></li>
                                            <li><a href="#">Event &amp; News</a></li>
                                            <li><a href="#">Blog &amp; Article</a></li>
                                            <li><a href="career">Career</a></li>
                                            <li><a href="contact">Contacts</a></li>
                                        </ul>
                                    </nav>
                                </div>{/* /.footer-widget__content */}
                            </div>{/* /.col-lg-2 */}
                            <div className="col-sm-6 col-md-6 col-lg-4 footer-widget footer-widget-nav">
                                <h6 className="footer-widget__title">Solutions</h6>
                                <div className="footer-widget__content">
                                    <nav>
                                        <ul className="list-unstyled">
                                            <li><a href="salesforce">CRM/Salesforce</a></li>
                                            <li><a href="analytics">BI &amp; Analytics</a></li>
                                            <li><a href="digital-marketing">Digital Marketing</a></li>
                                            <li><a href="development">Software Development</a></li>
                                            <li><a href="database">Database Development</a></li>
                                            <li><a href="quality-assurance">Quality Assurance</a></li>
                                        </ul>
                                    </nav>
                                </div>{/* /.footer-widget__content */}
                            </div>{/* /.col-lg-2 */}
                            {/*
      <div class="col-sm-6 col-md-6 col-lg-3 footer-widget footer-widget-nav">
        <h6 class="footer-widget__title">Memberships</h6>
        <div class="footer-widget__content">
          <nav>
            <ul class="list-unstyled">
              <li><a href="http://www.bssuniversal.com/images/PSEB%202019-2020.jpg">Pakistan Software Export Board</a></li>
              <li><a href="http://www.bssuniversal.com/images/P@sha-Membership-Certificate-2021-22.jpg">Pakistan Software Houses Association</a></li>
              <li><a href="http://www.bssuniversal.com/images/LCCI%20CERTIFICATION.jpg">Lahore Chamber of Commerce & Industry</a></li>
            </ul>
          </nav>
        </div>
      </div>
*/}
                        </div>{/* /.row */}
                    </div>{/* /.footer-primary */}
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-12 text-center pb-40">
                            <span className="fz-14">© 2021 BSS Universal, All Rights Reserved.</span>
                        </div>{/* /.col-lg-12 */}
                    </div>{/* /.row */}
                </div>{/* /.container */}
            </footer>{/* /.Footer */}
            <button id="scrollTopBtn"><i className="fas fa-long-arrow-alt-up" /></button>
        </div>

    );

}
export default digitalmarketing;