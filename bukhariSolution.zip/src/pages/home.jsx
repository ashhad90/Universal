function home() {
    return (
        <div className="wrapper">
            <div className="preloader">
                <div className="loading"><span></span><span></span><span></span><span></span></div>
            </div>
            <div className="header header-transparent">
                <div className="navbar navbar-expand-lg sticky-navbar">
                    <div className="container">
                        <a className="navbar-brand" href="/">
                            <img src="assets/images/logo/logo-light.png" className="logo-light" alt="logo" />
                            <img src="assets/images/logo/logo-dark.png" className="logo-dark" alt="logo" />
                        </a>
                        <button className="navbar-toggler" type="button">
                            <span className="menu-lines"><span></span></span>
                        </button>
                        <div className="collapse navbar-collapse" id="mainNavigation">
                            <ul className="navbar-nav ml-auto">
                                <li className="nav__item">
                                    <a href="/" className="dropdown-toggle nav__item-link active">Home</a>
                                </li>
                                {/* <!-- /.nav-item --> */}
                                <li className="nav__item has-dropdown">
                                    <a href="about-us" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Company</a>
                                    <ul className="dropdown-menu">
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">About Us</a>
                                        </li>
                                        {/* <!-- /.nav-item --> */}
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">CEO Message</a>
                                        </li>
                                        {/* <!-- /.nav-item --> */}
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">Our Mission</a>
                                        </li>
                                        {/* <!-- /.nav-item --> */}
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">Our Values</a>
                                        </li>
                                        {/* <!-- /.nav-item --> */}
                                        <li className="nav__item">
                                            <a href="about-us" className="nav__item-link">Our Team</a>
                                        </li>
                                        {/* <!-- /.nav-item --> */}
                                    </ul>
                                    {/* <!-- /.dropdown-menu --> */}
                                </li>
                                {/* <!-- /.nav-item --> */}
                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Services</a>
                                    <ul className="dropdown-menu">
                                        <li className="nav__item">
                                            <a href="salesforce" className="nav__item-link">CRM/Salesforce</a>
                                        </li>
                                        {/* <!-- /.nav-item --> */}
                                        <li className="nav__item">
                                            <a href="analytics" className="nav__item-link">BI &amp; Analytics</a>
                                        </li>
                                        {/* <!-- /.nav-item --> */}
                                        <li className="nav__item">
                                            <a href="digital-marketing" className="nav__item-link">Digital Marketing</a>
                                        </li>
                                        {/* <!-- /.nav-item --> */}
                                        <li className="nav__item">
                                            <a href="development" className="nav__item-link">Software Development</a>
                                        </li>
                                        {/* <!-- /.nav-item --> */}
                                        <li className="nav__item">
                                            <a href="database" className="nav__item-link">Database Development</a>
                                        </li>
                                        {/* <!-- /.nav-item --> */}
                                        <li className="nav__item">
                                            <a href="quality-assurance" className="nav__item-link">Quality Assurance</a>
                                        </li>
                                        {/* <!-- /.nav-item --> */}
                                    </ul>
                                    {/* <!-- /.dropdown-menu --> */}
                                </li>
                                {/* <!-- /.nav-item --> */}


                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Events</a>
                                    <ul className="dropdown-menu">
                                        <li className="nav__item">
                                            <a href="#" className="nav__item-link">News</a>
                                        </li>
                                        {/* <!-- /.nav-item --> */}
                                    </ul>
                                    {/* <!-- /.dropdown-menu --> */}
                                </li>
                                {/* <!-- /.nav-item --> */}
                                <li className="nav__item has-dropdown">
                                    <a href="career" className="nav__item-link">Career</a>

                                </li>
                                {/* <!-- /.nav-item --> */}
                                <li className="nav__item has-dropdown">
                                    <a href="#" data-toggle="dropdown" className="dropdown-toggle nav__item-link">Blog</a>

                                </li>
                                {/* !-- /.nav-item --> */}
                                <li className="nav__item">
                                    <a href="contact" className="nav__item-link">Contacts</a>
                                </li>
                                {/* <!-- /.nav-item --> */}
                            </ul>
                            {/* <!-- /.navbar-nav --> */}
                            <button className="close-mobile-menu d-block d-lg-none"><i className="fas fa-times"></i></button>
                        </div>
                        {/* <!-- /.navbar-collapse --> */}

                    </div>
                    {/* <!-- /.container --> */}
                </div>
                {/* <!-- /.navabr --> */}
            </div>
            {/* <!-- /.Header --> */}

            {/* <!-- ============================
      Slider
  ============================== --> */}
            <div className="section slider slider-layout2">
                <div className="slick-carousel carousel-arrows-light carousel-dots-light m-slides-0"
                    data-slick='{"slidesToShow": 1, "arrows": true, "dots": true, "speed": 700,"fade": true,"cssEase": "linear"}'>
                    <div className="slide-item align-v-h bg-overlay bg-overlay-gradient">
                        <div className="bg-img"><img src="assets/images/sliders/4.jpg" alt="slide img" /></div>
                        <div className="container">
                            <div className="row">
                                <div className="col-sm-12 col-md-12 col-lg-12 col-xl-7">
                                    <div className="slide__content">
                                        <h2 className="slide__title">Keep Business Safe And Ensure High Availability.</h2>
                                        <p className="slide__desc">BSS operates with an agile delivery framework to provide robust, reliable and scalable solutions for our clients surpassing their business expectations. </p>

                                    </div>
                                    {/* <!-- /.slide-content --> */}
                                </div>
                                {/* <!-- /.col-xl-7 --> */}
                            </div>
                        </div>
                        {/* <!-- /.container --> */}
                    </div>
                    {/* <!-- /.slide-item --> */}
                    <div className="slide-item align-v-h bg-overlay bg-overlay-gradient">
                        <div className="bg-img"><img src="assets/images/sliders/3.jpg" alt="slide img" /></div>
                        <div className="container">
                            <div className="row">
                                <div className="col-sm-12 col-md-12 col-lg-12 col-xl-7">
                                    <div className="slide__content">
                                        <h2 className="slide__title">Excellent IT support to our customers 24/7</h2>
                                        <p className="slide__desc">We have highly experienced and certified teams who have the experience of working with International as well as National Clients. </p>

                                    </div>
                                    {/* <!-- /.slide-content --> */}
                                </div>
                                {/* <!-- /.col-xl-7 --> */}
                            </div>
                        </div>
                        {/* <!-- /.container --> */}
                    </div>
                    {/* <!-- /.slide-item --> */}
                </div>
                {/* <!-- /.carousel --> */}
            </div>
            {/* <!-- /.slider --> */}
            {/* 
  <!-- ======================
  Core Value
  ========================= --> */}
            <div className="section features-layout4 bg-overlay bg-overlay-primary bg-parallax pt-0 pb-50">
                <div className="bg-img"><img src="assets/images/banners/4.jpg" alt="background" /></div>
                <div className="container">
                    <div className="row">
                        {/* <!-- Feature item #1 --> */}
                        <div className="col-sm-6 col-md-6 col-lg-3">
                            <div className="feature-item">
                                <div className="feature__icon">
                                    <i className="icon-cloud"></i>
                                </div>
                                <h4 className="feature__title">ISO 27001:2013 Security Systems</h4>
                                <a href="iso" className="btn__link">
                                    <i className="icon-arrow-right icon-outlined"></i>
                                    <span>Read More</span>
                                </a>
                            </div>
                            {/* <!-- /.feature-item --> */}
                        </div>
                        {/* <!-- /.col-lg-3 --> */}

                        {/* <!-- Feature item #2 --> */}
                        <div className="col-sm-6 col-md-6 col-lg-3">
                            <div className="feature-item">
                                <div className="feature__icon">
                                    <i className="icon-technician"></i>
                                </div>
                                <h4 className="feature__title">Enterprise Service & Dedicated Team</h4>
                                <a href="about-us" className="btn__link">
                                    <i className="icon-arrow-right icon-outlined"></i>
                                    <span>Read More</span>
                                </a>
                            </div>
                            {/* <!-- /.feature-item --> */}
                        </div>
                        {/* <!-- /.col-lg-3 --> */}

                        {/* <!-- Feature item #3 --> */}
                        <div className="col-sm-6 col-md-6 col-lg-3">
                            <div className="feature-item">
                                <div className="feature__icon">
                                    <i className="icon-website"></i>
                                </div>
                                <h4 className="feature__title">Knowledge Base 24/7 Support</h4>
                                <a href="about-us" className="btn__link">
                                    <i className="icon-arrow-right icon-outlined"></i>
                                    <span>Read More</span>
                                </a>
                            </div>
                            {/* <!-- /.feature-item --> */}
                        </div>
                        {/* <!-- /.col-lg-3 --> */}

                        {/* <!-- Feature item #4 --> */}
                        <div className="col-sm-6 col-md-6 col-lg-3">
                            <div className="feature-item">
                                <div className="feature__icon">
                                    <i className="icon-protection"></i>
                                </div>
                                <h4 className="feature__title">Reliability & Budget Friendly</h4>
                                <a href="about-us" className="btn__link">
                                    <i className="icon-arrow-right icon-outlined"></i>
                                    <span>Read More</span>
                                </a>
                            </div>
                            {/* <!-- /.feature-item --> */}
                        </div>
                        {/* <!-- /.col-lg-3 --> */}
                    </div>
                    <div className="row mt-30">
                        <div className="col-sm-12 col-md-12 col-lg-6">
                            <blockquote className="blockquote">
                                <h4 className="blockquote__title">We Are Privileged To Provide Support To More Than 70 Countries From Asia, Africa and Latin America. We Are Now Entering The European Market As Well.
                                </h4>

                                {/* <!-- <span className="blockquote__author">Tanweer Siddique, CEO</span> --> */}
                            </blockquote>
                        </div>
                        {/* <!-- /.col-lg-6 --> */}
                        <div className="col-sm-12 col-md-12 col-lg-6">

                            <span className="blockquote__author">Our Trusted Clients</span>

                            <div className="slick-carousel clients-light"
                                data-slick='{"slidesToShow": 4, "arrows": false, "dots": false, "autoplay": true,"autoplaySpeed": 2000, "infinite": true, "responsive": [ {"breakpoint": 992, "settings": {"slidesToShow": 3}}, {"breakpoint": 767, "settings": {"slidesToShow": 3}}, {"breakpoint": 480, "settings": {"slidesToShow": 2}}]}'>
                                <div className="client">
                                    <img src="assets/images/clients/1.png" alt="client" />
                                    <img src="assets/images/clients/1.png" alt="client" />
                                </div>
                                {/* <!-- /.client --> */}
                                <div className="client">
                                    <img src="assets/images/clients/2.png" alt="client" />
                                    <img src="assets/images/clients/2.png" alt="client" />
                                </div>
                                {/* <!-- /.client --> */}
                                <div className="client">
                                    <img src="assets/images/clients/3.png" alt="client" />
                                    <img src="assets/images/clients/3.png" alt="client" />
                                </div>
                                {/* <!-- /.client --> */}


                            </div>
                            {/* <!-- /.carousel --> */}
                        </div>
                        {/* <!-- /.col-lg-6 --> */}
                    </div>
                </div>
                {/* <!-- /.container --> */}
            </div>
            {/* <!-- /.Core Value --> */}

            {/* <!-- ========================
      Services
  =========================== --> */}
            <div className="section services-layout1">
                <div className="bg-img"><img src="assets/images/backgrounds/5.png" alt="backgrounds" /></div>
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
                            <div className="heading text-center mb-50">
                                <h2 className="heading__subtitle font_lower">Worldwide Services and Creative Expertise</h2>
                                <h3 className="heading__title">We Offer Latest Software And Customized Solutions To Our Customers! </h3>
                            </div>
                            {/* <!-- /.heading --> */}
                        </div>
                        {/* <!-- /.col-lg-6 --> */}
                    </div>
                    <div className="row">

                        {/* <!-- service item #1 --> */}
                        <div className="col-sm-12 col-md-6 col-lg-4">
                            <div className="service-item">
                                <div className="service__icon">
                                    <i className="icon-hosting"></i>
                                </div>
                                {/* <!-- /.service__icon --> */}
                                <h4 className="service__title">CRM/Salesforce</h4>
                                <div className="service__content">
                                    <p className="service__desc">Our Salesforce developers are the key to your commerce victory. We offer a extend of end-to-end arrangements for Salesforce CRM with our highly trained, skilled, experienced, and certified developers.
                                    </p>
                                    <a href="salesforce" className="btn btn__primary">
                                        <span>Read More</span>
                                        <i className="icon-arrow-right"></i>
                                    </a>
                                </div>
                                {/* <!-- /.service-content --> */}
                            </div>
                            {/* <!-- /.service-item --> */}
                        </div>
                        {/* <!-- /.col-lg-4 --> */}

                        <div className="col-sm-12 col-md-6 col-lg-4">
                            <div className="service-item">
                                <div className="service__icon">
                                    <i className="icon-presentation"></i>
                                </div>
                                {/* <!-- /.service__icon --> */}
                                <h4 className="service__title">BI &amp; Analytics</h4>
                                <div className="service__content">
                                    <p className="service__desc">Our highly specialized BI consultants help you select, optimize and deploy an array of custom and pre-built analytics to help you better understand your customers.</p>
                                    <a href="analytics" className="btn btn__primary">
                                        <span>Read More</span>
                                        <i className="icon-arrow-right"></i>
                                    </a>
                                </div>
                                {/* <!-- /.service-content --> */}
                            </div>
                            {/* <!-- /.service-item --> */}
                        </div>
                        {/* <!-- /.col-lg-4 --> */}

                        <div className="col-sm-12 col-md-6 col-lg-4">
                            <div className="service-item">
                                <div className="service__icon">
                                    <i className="icon-network"></i>
                                </div>
                                {/* <!-- /.service__icon --> */}
                                <h4 className="service__title">Digital Marketing</h4>
                                <div className="service__content">
                                    <p className="service__desc">We Merge Imagination And Technology To Help Brands Grow In An Age Of Digital Transformation. We always stand at the forefront of all emerging trends in digital marketing.
                                    </p>
                                    <a href="digital-marketing" className="btn btn__primary">
                                        <span>Read More</span>
                                        <i className="icon-arrow-right"></i>
                                    </a>
                                </div>
                                {/* <!-- /.service-content --> */}
                            </div>
                            {/* <!-- /.service-item --> */}
                        </div>
                        {/* <!-- /.col-lg-4 --> */}


                        {/* <!-- service item #2 --> */}
                        <div className="col-sm-12 col-md-6 col-lg-4">
                            <div className="service-item">
                                <div className="service__icon">
                                    <i className="icon-programming"></i>
                                </div>
                                {/* <!-- /.service__icon --> */}
                                <h4 className="service__title">Software Development</h4>
                                <div className="service__content">
                                    <p className="service__desc">Our software developers construct custom software solutions and fastidiously take after business forms to provide a product that includes substantial esteem to your business.</p>
                                    <a href="development" className="btn btn__primary">
                                        <span>Read More</span>
                                        <i className="icon-arrow-right"></i>
                                    </a>
                                </div>
                                {/* <!-- /.service-content --> */}
                            </div>
                            {/* <!-- /.service-item --> */}
                        </div>
                        {/* <!-- /.col-lg-4 --> */}

                        {/* <!-- service item #3 --> */}

                        <div className="col-sm-12 col-md-6 col-lg-4">
                            <div className="service-item">
                                <div className="service__icon">
                                    <i className="icon-server"></i>
                                </div>
                                {/* <!-- /.service__icon --> */}
                                <h4 className="service__title">Database Management</h4>
                                <div className="service__content">
                                    <p className="service__desc">Our database solutions help you optimize collecting, accessing, managing, analyzing, processing and disbursing data - ensuring high security.</p>
                                    <a href="database" className="btn btn__primary">
                                        <span>Read More</span>
                                        <i className="icon-arrow-right"></i>
                                    </a>
                                </div>
                                {/* <!-- /.service-content --> */}
                            </div>
                            {/* <!-- /.service-item --> */}
                        </div>
                        {/* <!-- /.col-lg-4 --> */}


                        {/* <!-- service item #4 --> */}
                        <div className="col-sm-12 col-md-6 col-lg-4">
                            <div className="service-item">
                                <div className="service__icon">
                                    <i className="icon-transaction"></i>
                                </div>
                                {/* {<!-- /.service__icon -->//  */}
                                <h4 className="service__title">Quality Assurance</h4>
                                <div className="service__content">
                                    <p className="service__desc">BSS is a software development firm which offers full-cycle software development services, including QA testing at every stage of the development process.</p>
                                    <a href="quality-assurance" className="btn btn__primary">
                                        <span>Read More</span>
                                        <i className="icon-arrow-right"></i>
                                    </a>
                                </div>
                                {/* <!-- /.service-content --> */}
                            </div>
                            {/* <!-- /.service-item --> */}
                        </div>
                        {/* <!-- /.col-lg-4 --> */}
                        {/* <!-- service item #5 -->
        
        <!-- service item #6 --> */}

                    </div>
                </div>
                {/* <!-- /.container --> */}
            </div>
            {/* <!-- /.Services--> */}

            {/*       
    <!-- ======================
    Work Process 
  ========================= --> */}
            <div className="section work-process pt-130 pb-130">
                <div className="bg-img"><img src="assets/images/backgrounds/2.jpg" alt="background" /></div>
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-6 col-xl-7">
                            <div className="banners-wrapper sticky-top">
                                <div className="tab-content mb-50">
                                    <div className="tab-pane fade show active" id="tab1">
                                        <div className="video__banner">
                                            <img src="assets/images/work-process/1.jpg" className="rounded" alt="banner" />

                                        </div>
                                        {/* <!-- /.video__banner --> */}
                                    </div>
                                    <div className="tab-pane fade" id="tab2">
                                        <div className="video__banner">
                                            <img src="assets/images/work-process/2.jpg" className="rounded" alt="banner" />

                                        </div>
                                        {/* <!-- /.video__banner --> */}
                                    </div>
                                    <div className="tab-pane fade" id="tab3">
                                        <div className="video__banner">
                                            <img src="assets/images/work-process/3.jpg" className="rounded" alt="banner" />

                                        </div>
                                        {/* <!-- /.video__banner --> */}
                                    </div>
                                    <div className="tab-pane fade" id="tab4">
                                        <div className="video__banner">
                                            <img src="assets/images/work-process/4.jpg" className="rounded" alt="banner" />

                                        </div>
                                        {/* <!-- /.video__banner --> */}
                                    </div>
                                </div>
                                {/* <!-- /.tab-content --> */}
                                <div className="cta-banner mt-30 mb-30 d-flex flex-wrap align-items-center">
                                    <h4 className="cta__title my-3 pr-30 font_lower">
                                        Our core focus is to provide quality services enabling our clients to focus on their core business. Ready to start your next
                                        project? Drop us a line or two at: <a href="mailto:consult@bssuniversal.com">consult@bssuniversal.com</a>
                                    </h4>
                                    <a href="contact" className="btn btn__primary btn__primary-style2">
                                        <span>Request Demo</span>
                                        <i className="icon-arrow-right"></i>
                                    </a>
                                </div>
                                {/* <!-- /.cta-banner --> */}
                            </div>
                        </div>
                        {/* <!-- /.col-lg-7 --> */}
                        <div className="col-sm-12 col-md-12 col-lg-6 col-xl-5">
                            <div className="heading mb-70">
                                <h2 className="heading__subtitle color-primary">How We Works!!</h2>
                                <h3 className="heading__title color-white">Deliver Only Exceptional Quality, And Improve! </h3>
                            </div>
                            <nav className="nav nav-tabs">
                                {/* <!-- process Item #1 --> */}
                                <a className="process-item active" data-toggle="tab" href="#tab1">
                                    <div className="process-item__content">
                                        <h4 className="process-item__title">Brainstorming</h4>
                                        <p className="process-item__desc">The first step is to take the projects data & think about it to manage
                                            all aspects of your software assets including maintenance.</p>
                                    </div>
                                </a>
                                {/* <!-- /.process-item --> */}
                                {/* <!-- process Item #2 --> */}
                                <a className="process-item" data-toggle="tab" href="#tab2">
                                    <div className="process-item__content">
                                        <h4 className="process-item__title">Concept Prototype</h4>
                                        <p className="process-item__desc">To know about the product, customers & competitors offer integral
                                            communication services software assets.
                                        </p>
                                    </div>
                                </a>
                                {/* <!-- /.process-item --> */}
                                {/* <!-- process Item #3 --> */}
                                <a className="process-item" data-toggle="tab" href="#tab3">
                                    <div className="process-item__content">
                                        <h4 className="process-item__title">Design Layout</h4>
                                        <p className="process-item__desc">Start to work on the design taking with collected data, we're
                                            responsible for our process and results.
                                        </p>
                                    </div>
                                </a>
                                {/* <!-- /.process-item --> */}
                                {/* <!-- process Item #4 --> */}
                                <a className="process-item" data-toggle="tab" href="#tab4">
                                    <div className="process-item__content">
                                        <h4 className="process-item__title">Evaluation</h4>
                                        <p className="process-item__desc">Reach a conclusion from the investigations about the product and we thank
                                            each of our great clients projects.</p>
                                    </div>
                                </a>
                                {/* <!-- /.process-item --> */}
                            </nav>
                        </div>
                        {/* <!-- /.col-lg-5 --> */}
                    </div>
                </div>
                {/* <!-- /.container --> */}
            </div>
            {/* <!-- /.Work Process --> */}

            {/* <!-- =========================== 
    News and Event
  ============================= --> */}
            <div className="section portfolio-layout2 portfolio-layout2-carousel pb-50">
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-12 text-center">
                            <div className="heading mb-50">
                                <h2 className="heading__subtitle color-body">Corporate announcements, upcoming events and recent wins</h2>
                                <h3 className="heading__title">Insights Stories</h3>
                            </div>
                            {/* <!-- /heading --> */}
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12">
                            <div className="slick-carousel"
                                data-slick='{"slidesToShow": 3, "slidesToScroll": 3, "arrows": false, "dots": true, "responsive": [ {"breakpoint": 992, "settings": {"slidesToShow": 2}}, {"breakpoint": 767, "settings": {"slidesToShow": 2}}, {"breakpoint": 480, "settings": {"slidesToShow": 1}}]}'>
                                {/* <!-- portfolio item #1 --> */}
                                <div className="portfolio-item">
                                    <div className="portfolio__img">
                                        <a><img src="assets/images/portfolio/modern/1.jpg"
                                            alt="portfolio img" /></a>
                                    </div>
                                    {/* <!-- /.portfolio-img --> */}
                                    <div className="portfolio__icon">
                                        <img src="assets/images/icons/1.png" alt="icon" />
                                    </div>
                                    {/* <!-- /.portfolio__icon --> */}
                                    <div className="portfolio__content">
                                        <h4 className="portfolio__title"><a>ISO 27001:2013 certification</a></h4>
                                        <p className="portfolio__desc">BSS recognizes the importance of Data Privacy and Cybersecurity and has been practicing ISMS and have been audited for ISO 27001:2013 certification.</p>
                                        {/* <!--
                <a href="#" className="btn btn__secondary btn__link">
                  <span>Read More</span>
                  <i className="icon-arrow-right"></i>
                </a>
  --> */}
                                    </div>
                                    {/* <!-- /.portfolio-content --> */}
                                </div>
                                {/* <!-- /.portfolio-item --> */}
                                {/* <!-- portfolio item #2 --> */}
                                <div className="portfolio-item">
                                    <div className="portfolio__img">
                                        <a><img src="assets/images/portfolio/modern/2.jpg"
                                            alt="portfolio img" /></a>
                                    </div>
                                    {/* <!-- /.portfolio-img --> */}
                                    <div className="portfolio__icon">
                                        <img src="assets/images/icons/2.png" alt="icon" />
                                    </div>
                                    {/* <!-- /.portfolio__icon --> */}
                                    <div className="portfolio__content">
                                        <h4 className="portfolio__title"><a>Dubai Office </a></h4>
                                        <p className="portfolio__desc">We are privileged to provide support to more than 70 countries from
                                            Asia, Africa, Latin America and are now entering the European market as well. That’s how we are expanding worldwide.</p>
                                        {/* <!--
                <a href="#" className="btn btn__secondary btn__link">
                  <span>Read More</span>
                  <i className="icon-arrow-right"></i>
                </a>
  --> */}
                                    </div>
                                    {/* <!-- /.portfolio-content --> */}
                                </div>
                                {/* <!-- /.portfolio-item --> */}
                                {/* <!-- portfolio item #3 --> */}
                                <div className="portfolio-item">
                                    <div className="portfolio__img">
                                        <a><img src="assets/images/portfolio/modern/3.jpg"
                                            alt="portfolio img" /></a>
                                    </div>
                                    {/* <!-- /.portfolio-img --> */}
                                    <div className="portfolio__icon">
                                        <img src="assets/images/icons/3.png" alt="icon" />
                                    </div>
                                    {/* <!-- /.portfolio__icon --> */}
                                    <div className="portfolio__content">
                                        <h4 className="portfolio__title"><a>Corporate Dinner and Awards Distribution 2021</a></h4>
                                        <p className="portfolio__desc">Business Solutions & Services holds Annual Dinner and Awards Night. We, at BSS celebrate the success of our ever growing company by award distribution ceremony</p>
                                        {/* <!--
                <a href="case-studies-single" className="btn btn__secondary btn__link">
                  <span>Read More</span>
                  <i className="icon-arrow-right"></i>
                </a>
  --> */}
                                    </div>
                                    {/* <!-- /.portfolio-content --> */}
                                </div>
                                {/* <!-- /.portfolio-item --> */}
                                {/* <!-- portfolio item #4 --> */}
                                <div className="portfolio-item">
                                    <div className="portfolio__img">
                                        <a><img src="assets/images/portfolio/modern/4.jpg"
                                            alt="portfolio img" /></a>
                                    </div>
                                    {/* <!-- /.portfolio-img --> */}
                                    <div className="portfolio__icon">
                                        <img src="assets/images/icons/4.png" alt="icon" />
                                    </div>
                                    {/* <!-- /.portfolio__icon --> */}
                                    <div className="portfolio__content">
                                        <h4 className="portfolio__title"><a>The LCCI Membership Certificate</a></h4>
                                        <p className="portfolio__desc">March 04, 2021, Islamabad – The Lahore Chamber of Commerce & Industry (LCCI) honors BSS with the  LCCI Membership Certificate</p>
                                        {/* <!--
                <a href="case-studies-single" className="btn btn__secondary btn__link">
                  <span>Read More</span>
                  <i className="icon-arrow-right"></i>
                </a>
  --> */}
                                    </div>
                                    {/* <!-- /.portfolio-content --> */}
                                </div>
                                {/* <!-- /.portfolio-item --> */}
                                {/* <!-- portfolio item #5 --> */}
                                <div className="portfolio-item">
                                    <div className="portfolio__img">
                                        <a><img src="assets/images/portfolio/modern/5.jpg"
                                            alt="portfolio img" /></a>
                                    </div>
                                    {/* <!-- /.portfolio-img --> */}
                                    <div className="portfolio__icon">
                                        <img src="assets/images/icons/5.png" alt="icon" />
                                    </div>
                                    {/* <!-- /.portfolio__icon --> */}
                                    <div className="portfolio__content">
                                        <h4 className="portfolio__title"><a>Business Solutions & Services is a Corporate Member of PASHA</a></h4>
                                        <p className="portfolio__desc">pakistan software house association (PASHA) honors BSS with the Corporate Member Certificate</p>
                                        {/* <!--
                <a href="#" className="btn btn__secondary btn__link">
                  <span>Read More</span>
                  <i className="icon-arrow-right"></i>
                </a>
  --> */}
                                    </div>
                                    {/* <!-- /.portfolio-content --> */}
                                </div>
                                {/* <!-- /.portfolio-item --> */}
                                {/* <!-- portfolio item #6 --> */}
                                <div className="portfolio-item">
                                    <div className="portfolio__img">
                                        <a><img src="assets/images/portfolio/modern/6.jpg"
                                            alt="portfolio img" /></a>
                                    </div>
                                    {/* <!-- /.portfolio-img --> */}
                                    <div className="portfolio__icon">
                                        <img src="assets/images/icons/6.png" alt="icon" />
                                    </div>
                                    {/* <!-- /.portfolio__icon --> */}
                                    <div className="portfolio__content">
                                        <h4 className="portfolio__title"><a>Organised a Cricket Tournament 2019</a></h4>
                                        <p className="portfolio__desc">BSS continuously focus on employee health and physical activity.
                                            Cricket Tournament is the one of best activity for employees</p>
                                        {/* <!--
                <a href="#" className="btn btn__secondary btn__link">
                  <span>Read More</span>
                  <i className="icon-arrow-right"></i>
                </a>
  --> */}
                                    </div>
                                    {/* <!-- /.portfolio-content --> */}
                                </div>
                                {/* <!-- /.portfolio-item --> */}
                            </div>
                            {/* <!-- /.carousel --> */}
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 text-center">
                            <p className="text__link mb-0">Working hard to earn our customers’ trust.
                                <a className="btn btn__secondary btn__link mx-1">
                                    <span>Swipe To Explore All Insights</span> <i className="icon-arrow-right icon-outlined"></i>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
                {/* <!-- /.container --> */}
            </div>
            {/* <!-- /.News and Event -->      */}

            {/* <!-- ========================
      Footer
    ========================== --> */}
            <footer className="footer bg-secondary">
                <div className="container">
                    <div className="footer-top pt-50 pb-30">
                        <div className="row">
                            <div className="col-sm-4 col-md-2 col-lg-4">
                                <img src="assets/images/logo/logo-light-small.png" alt="logo" className="mb-30" />
                            </div>
                            {/* <!-- /.col-lg-2 --> */}
                            <div className="col-sm-8 col-md-4 col-lg-3">
                                <h6 className="footer-top__title">Sign up for latest IT resources,
                                    news and insights from BSS!</h6>
                            </div>
                            {/* <!-- /.col-lg-3 --> */}
                            <div className="col-sm-12 col-md-6 col-lg-5">
                                <form className="footer-form d-flex mb-0">
                                    <input type="email" className="form-control mr-20" placeholder="Your Email Address" />
                                    <button type="submit" className="btn btn__primary btn__primary-style2">
                                        <span>Subscribe</span>
                                        <i className="icon-arrow-right"></i>
                                    </button>
                                </form>
                            </div>
                            {/* <!-- /.col-lg-6 --> */}
                        </div>
                    </div>
                    {/* <!-- /.footer-top --> */}
                    <div className="footer-primary">
                        <div className="row">
                            <div className="col-sm-12 col-md-12 col-lg-4 footer-widget footer-widget-about">
                                <div className="footer-widget__content">
                                    <div className="contact-info">
                                        <h6 className="footer-widget__title">Quick Contact</h6>
                                        <ul className="contact-list list-unstyled">
                                            <li className="color-gray">If you have any questions or need help, feel free to contact with our team.
                                            </li>
                                            <li className="mt-20 mb-20">
                                                <a href="mailto:consult@bssuniversal.com" className="phone-number">
                                                    <span>consult@bssuniversal.com</span>
                                                </a>
                                            </li>
                                            <li className="color-body"><a href="contact">Dubai | United States | Pakistan</a></li>
                                        </ul>
                                    </div>
                                    {/* <!-- /.contact-info --> */}
                                    <ul className="social-icons list-unstyled mb-0">
                                        <li><a href="https://www.facebook.com/bssuniversal" target="_blank"><i className="fab fa-facebook-f"></i></a></li>
                                        <li><a href="https://www.linkedin.com/company/bssuniversal/" target="_blank"><i className="fab fa-linkedin"></i></a></li>
                                        <li><a href="https://twitter.com/bssuniversal" target="_blank"><i className="fab fa-twitter"></i></a></li>
                                        <li><a href="https://www.instagram.com/bss.global12/?hl=en" target="_blank"><i className="fab fa-instagram"></i></a></li>
                                    </ul>
                                    {/* <!-- /.social-icons --> */}
                                </div>
                                {/* <!-- /.footer-widget__content --> */}
                            </div>
                            {/* <!-- /.col-xl-2 --> */}
                            <div className="col-sm-6 col-md-6 col-lg-3 offset-lg-1 footer-widget footer-widget-nav">
                                <h6 className="footer-widget__title">Company</h6>
                                <div className="footer-widget__content">
                                    <nav>
                                        <ul className="list-unstyled">
                                            <li><a href="about-us">About Us</a></li>
                                            <li><a href="about-us">Our Team</a></li>
                                            <li><a href="#">Event & News</a></li>
                                            <li><a href="#">Blog & Article</a></li>
                                            <li><a href="career">Career</a></li>
                                            <li><a href="contact">Contacts</a></li>
                                        </ul>
                                    </nav>
                                </div>
                                {/* <!-- /.footer-widget__content --> */}
                            </div>
                            {/* <!-- /.col-lg-2 --> */}
                            <div className="col-sm-6 col-md-6 col-lg-4 footer-widget footer-widget-nav">
                                <h6 className="footer-widget__title">Solutions</h6>
                                <div className="footer-widget__content">
                                    <nav>
                                        <ul className="list-unstyled">
                                            <li><a href="salesforce">CRM/Salesforce</a></li>
                                            <li><a href="analytics">BI &amp; Analytics</a></li>
                                            <li><a href="digital-marketing">Digital Marketing</a></li>
                                            <li><a href="development">Software Development</a></li>
                                            <li><a href="database">Database Development</a></li>
                                            <li><a href="quality-assurance">Quality Assurance</a></li>
                                        </ul>
                                    </nav>
                                </div>
                                {/* <!-- /.footer-widget__content --> */}
                            </div>
                            {/* <!-- /.col-lg-2 --> */}

                            {/* <!--
          <div className="col-sm-6 col-md-6 col-lg-3 footer-widget footer-widget-nav">
            <h6 className="footer-widget__title">Memberships</h6>
            <div className="footer-widget__content">
              <nav>
                <ul className="list-unstyled">
                  <li><a href="http://www.bssuniversal.com/images/PSEB%202019-2020.jpg">Pakistan Software Export Board</a></li>
                  <li><a href="http://www.bssuniversal.com/images/P@sha-Membership-Certificate-2021-22.jpg">Pakistan Software Houses Association</a></li>
                  <li><a href="http://www.bssuniversal.com/images/LCCI%20CERTIFICATION.jpg">Lahore Chamber of Commerce & Industry</a></li>
                </ul>
              </nav>
            </div>
          </div>
  --> */}

                        </div>
                    </div>
                    <div className="row">
                        <div className="col-sm-12 col-md-12 col-lg-12 text-center pb-40">
                            <span className="fz-14">&copy; 2021 BSS Universal, All Rights Reserved.</span>
                        </div>
                    </div>
                </div>
            </footer>

            <button id="scrollTopBtn"><i className="fas fa-long-arrow-alt-up"></i></button>

        </div>
    );
}

export default home;