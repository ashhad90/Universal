import React from 'react';
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/home";
import About from "./pages/about-us";
import Career from "./pages/career";
import Contact from "./pages/contact";
import Analytics from "./pages/analytics";
import Database from "./pages/database";
import Development from "./pages/development";
import Digitalmarketing from "./pages/digital-marketing";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about-us" element={<About />} />
        <Route path="/career" element={<Career />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/database" element={<Database />} />
        <Route path="/development" element={<Development />} />
        <Route path="/digital-marketing" element={<Digitalmarketing />} />
      </Routes>
    </BrowserRouter>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);